/* @ds-bundle: {"format":4,"namespace":"GreenhuebluesDesignSystem_653a8b","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Link","sourcePath":"components/actions/Link.jsx"},{"name":"Icon","sourcePath":"components/brand/Icon.jsx"},{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"Tag","sourcePath":"components/display/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Field","sourcePath":"components/forms/Input.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"RadioGroup","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"e8c520d44934","components/actions/IconButton.jsx":"38e06877cc56","components/actions/Link.jsx":"56673c4cfa7b","components/brand/Icon.jsx":"86d8500af6f0","components/brand/Logo.jsx":"d7d84462b8ed","components/display/Badge.jsx":"d209af48ae89","components/display/Card.jsx":"5058aef3e90a","components/display/Tag.jsx":"7241220d03e0","components/feedback/Dialog.jsx":"1435d5879a9d","components/feedback/Toast.jsx":"40d1ea76d7d3","components/feedback/Tooltip.jsx":"c3fc793155b2","components/forms/Checkbox.jsx":"46cc6b074124","components/forms/Input.jsx":"f3e5a0f375ba","components/forms/Radio.jsx":"ce6f99d31fdf","components/forms/Select.jsx":"71cacfb5d489","components/forms/Switch.jsx":"f0884266483d","components/navigation/Tabs.jsx":"a6a12eb0143a","ui_kits/website/Art.jsx":"944f6b907307","ui_kits/website/ContactScreen.jsx":"71275f621973","ui_kits/website/Footer.jsx":"b8e68d27ee04","ui_kits/website/Header.jsx":"c9625e16dcae","ui_kits/website/HomeScreen.jsx":"7d63efabc07c","ui_kits/website/IndexList.jsx":"16f4c3028b18","ui_kits/website/ProjectScreen.jsx":"4f47b3f3197e","ui_kits/website/StudioScreen.jsx":"bb6b90436d4e","ui_kits/website/WorkScreen.jsx":"d98733a0715b","ui_kits/website/data.js":"556da198ecd0","ui_kits/website/image-slot.js":"fff26d081c8d"},"inlinedExternals":[],"unexposedExports":[{"name":"fieldShell","sourcePath":"components/forms/Input.jsx"},{"name":"iconNames","sourcePath":"components/brand/Icon.jsx"}]} */

(() => {

const __ds_ns = (window.GreenhuebluesDesignSystem_653a8b = window.GreenhuebluesDesignSystem_653a8b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Icon paths copied verbatim from lucide-static@0.468.0 (ISC license). See assets/icons/ for the raw SVGs.
const ICONS = {
  "arrow-right": "<path d=\"M5 12h14\"/> <path d=\"m12 5 7 7-7 7\"/>",
  "arrow-left": "<path d=\"m12 19-7-7 7-7\"/> <path d=\"M19 12H5\"/>",
  "arrow-up": "<path d=\"m5 12 7-7 7 7\"/> <path d=\"M12 19V5\"/>",
  "arrow-down": "<path d=\"M12 5v14\"/> <path d=\"m19 12-7 7-7-7\"/>",
  "arrow-up-right": "<path d=\"M7 7h10v10\"/> <path d=\"M7 17 17 7\"/>",
  "arrow-down-right": "<path d=\"m7 7 10 10\"/> <path d=\"M17 7v10H7\"/>",
  "chevron-right": "<path d=\"m9 18 6-6-6-6\"/>",
  "chevron-left": "<path d=\"m15 18-6-6 6-6\"/>",
  "chevron-down": "<path d=\"m6 9 6 6 6-6\"/>",
  "chevron-up": "<path d=\"m18 15-6-6-6 6\"/>",
  "plus": "<path d=\"M5 12h14\"/> <path d=\"M12 5v14\"/>",
  "minus": "<path d=\"M5 12h14\"/>",
  "x": "<path d=\"M18 6 6 18\"/> <path d=\"m6 6 12 12\"/>",
  "check": "<path d=\"M20 6 9 17l-5-5\"/>",
  "menu": "<line x1=\"4\" x2=\"20\" y1=\"12\" y2=\"12\"/> <line x1=\"4\" x2=\"20\" y1=\"6\" y2=\"6\"/> <line x1=\"4\" x2=\"20\" y1=\"18\" y2=\"18\"/>",
  "search": "<circle cx=\"11\" cy=\"11\" r=\"8\"/> <path d=\"m21 21-4.3-4.3\"/>",
  "mail": "<rect width=\"20\" height=\"16\" x=\"2\" y=\"4\" rx=\"2\"/> <path d=\"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7\"/>",
  "phone": "<path d=\"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z\"/>",
  "map-pin": "<path d=\"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0\"/> <circle cx=\"12\" cy=\"10\" r=\"3\"/>",
  "globe": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <path d=\"M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20\"/> <path d=\"M2 12h20\"/>",
  "external-link": "<path d=\"M15 3h6v6\"/> <path d=\"M10 14 21 3\"/> <path d=\"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6\"/>",
  "link": "<path d=\"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71\"/> <path d=\"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71\"/>",
  "copy": "<rect width=\"14\" height=\"14\" x=\"8\" y=\"8\" rx=\"2\" ry=\"2\"/> <path d=\"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2\"/>",
  "download": "<path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/> <polyline points=\"7 10 12 15 17 10\"/> <line x1=\"12\" x2=\"12\" y1=\"15\" y2=\"3\"/>",
  "upload": "<path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/> <polyline points=\"17 8 12 3 7 8\"/> <line x1=\"12\" x2=\"12\" y1=\"3\" y2=\"15\"/>",
  "share-2": "<circle cx=\"18\" cy=\"5\" r=\"3\"/> <circle cx=\"6\" cy=\"12\" r=\"3\"/> <circle cx=\"18\" cy=\"19\" r=\"3\"/> <line x1=\"8.59\" x2=\"15.42\" y1=\"13.51\" y2=\"17.49\"/> <line x1=\"15.41\" x2=\"8.59\" y1=\"6.51\" y2=\"10.49\"/>",
  "info": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <path d=\"M12 16v-4\"/> <path d=\"M12 8h.01\"/>",
  "circle-alert": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <line x1=\"12\" x2=\"12\" y1=\"8\" y2=\"12\"/> <line x1=\"12\" x2=\"12.01\" y1=\"16\" y2=\"16\"/>",
  "circle-check": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <path d=\"m9 12 2 2 4-4\"/>",
  "triangle-alert": "<path d=\"m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3\"/> <path d=\"M12 9v4\"/> <path d=\"M12 17h.01\"/>",
  "circle-x": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <path d=\"m15 9-6 6\"/> <path d=\"m9 9 6 6\"/>",
  "loader-circle": "<path d=\"M21 12a9 9 0 1 1-6.219-8.56\"/>",
  "play": "<polygon points=\"6 3 20 12 6 21 6 3\"/>",
  "pause": "<rect x=\"14\" y=\"4\" width=\"4\" height=\"16\" rx=\"1\"/> <rect x=\"6\" y=\"4\" width=\"4\" height=\"16\" rx=\"1\"/>",
  "volume-2": "<path d=\"M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z\"/> <path d=\"M16 9a5 5 0 0 1 0 6\"/> <path d=\"M19.364 18.364a9 9 0 0 0 0-12.728\"/>",
  "image": "<rect width=\"18\" height=\"18\" x=\"3\" y=\"3\" rx=\"2\" ry=\"2\"/> <circle cx=\"9\" cy=\"9\" r=\"2\"/> <path d=\"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21\"/>",
  "file": "<path d=\"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z\"/> <path d=\"M14 2v4a2 2 0 0 0 2 2h4\"/>",
  "folder": "<path d=\"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z\"/>",
  "code": "<polyline points=\"16 18 22 12 16 6\"/> <polyline points=\"8 6 2 12 8 18\"/>",
  "terminal": "<polyline points=\"4 17 10 11 4 5\"/> <line x1=\"12\" x2=\"20\" y1=\"19\" y2=\"19\"/>",
  "layers": "<path d=\"M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z\"/> <path d=\"M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12\"/> <path d=\"M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17\"/>",
  "pen-tool": "<path d=\"M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z\"/> <path d=\"m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18\"/> <path d=\"m2.3 2.3 7.286 7.286\"/> <circle cx=\"11\" cy=\"11\" r=\"2\"/>",
  "palette": "<circle cx=\"13.5\" cy=\"6.5\" r=\".5\" fill=\"currentColor\"/> <circle cx=\"17.5\" cy=\"10.5\" r=\".5\" fill=\"currentColor\"/> <circle cx=\"8.5\" cy=\"7.5\" r=\".5\" fill=\"currentColor\"/> <circle cx=\"6.5\" cy=\"12.5\" r=\".5\" fill=\"currentColor\"/> <path d=\"M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z\"/>",
  "cpu": "<rect width=\"16\" height=\"16\" x=\"4\" y=\"4\" rx=\"2\"/> <rect width=\"6\" height=\"6\" x=\"9\" y=\"9\" rx=\"1\"/> <path d=\"M15 2v2\"/> <path d=\"M15 20v2\"/> <path d=\"M2 15h2\"/> <path d=\"M2 9h2\"/> <path d=\"M20 15h2\"/> <path d=\"M20 9h2\"/> <path d=\"M9 2v2\"/> <path d=\"M9 20v2\"/>",
  "layout-grid": "<rect width=\"7\" height=\"7\" x=\"3\" y=\"3\" rx=\"1\"/> <rect width=\"7\" height=\"7\" x=\"14\" y=\"3\" rx=\"1\"/> <rect width=\"7\" height=\"7\" x=\"14\" y=\"14\" rx=\"1\"/> <rect width=\"7\" height=\"7\" x=\"3\" y=\"14\" rx=\"1\"/>",
  "list": "<path d=\"M3 12h.01\"/> <path d=\"M3 18h.01\"/> <path d=\"M3 6h.01\"/> <path d=\"M8 12h13\"/> <path d=\"M8 18h13\"/> <path d=\"M8 6h13\"/>",
  "sliders-horizontal": "<line x1=\"21\" x2=\"14\" y1=\"4\" y2=\"4\"/> <line x1=\"10\" x2=\"3\" y1=\"4\" y2=\"4\"/> <line x1=\"21\" x2=\"12\" y1=\"12\" y2=\"12\"/> <line x1=\"8\" x2=\"3\" y1=\"12\" y2=\"12\"/> <line x1=\"21\" x2=\"16\" y1=\"20\" y2=\"20\"/> <line x1=\"12\" x2=\"3\" y1=\"20\" y2=\"20\"/> <line x1=\"14\" x2=\"14\" y1=\"2\" y2=\"6\"/> <line x1=\"8\" x2=\"8\" y1=\"10\" y2=\"14\"/> <line x1=\"16\" x2=\"16\" y1=\"18\" y2=\"22\"/>",
  "settings": "<path d=\"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z\"/> <circle cx=\"12\" cy=\"12\" r=\"3\"/>",
  "eye": "<path d=\"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0\"/> <circle cx=\"12\" cy=\"12\" r=\"3\"/>",
  "calendar": "<path d=\"M8 2v4\"/> <path d=\"M16 2v4\"/> <rect width=\"18\" height=\"18\" x=\"3\" y=\"4\" rx=\"2\"/> <path d=\"M3 10h18\"/>",
  "clock": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <polyline points=\"12 6 12 12 16 14\"/>",
  "user": "<path d=\"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2\"/> <circle cx=\"12\" cy=\"7\" r=\"4\"/>",
  "sun": "<circle cx=\"12\" cy=\"12\" r=\"4\"/> <path d=\"M12 2v2\"/> <path d=\"M12 20v2\"/> <path d=\"m4.93 4.93 1.41 1.41\"/> <path d=\"m17.66 17.66 1.41 1.41\"/> <path d=\"M2 12h2\"/> <path d=\"M20 12h2\"/> <path d=\"m6.34 17.66-1.41 1.41\"/> <path d=\"m19.07 4.93-1.41 1.41\"/>",
  "moon": "<path d=\"M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z\"/>",
  "ellipsis": "<circle cx=\"12\" cy=\"12\" r=\"1\"/> <circle cx=\"19\" cy=\"12\" r=\"1\"/> <circle cx=\"5\" cy=\"12\" r=\"1\"/>",
  "pencil": "<path d=\"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z\"/> <path d=\"m15 5 4 4\"/>",
  "trash-2": "<path d=\"M3 6h18\"/> <path d=\"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6\"/> <path d=\"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2\"/> <line x1=\"10\" x2=\"10\" y1=\"11\" y2=\"17\"/> <line x1=\"14\" x2=\"14\" y1=\"11\" y2=\"17\"/>",
  "bell": "<path d=\"M10.268 21a2 2 0 0 0 3.464 0\"/> <path d=\"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326\"/>",
  "bookmark": "<path d=\"m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z\"/>",
  "maximize-2": "<polyline points=\"15 3 21 3 21 9\"/> <polyline points=\"9 21 3 21 3 15\"/> <line x1=\"21\" x2=\"14\" y1=\"3\" y2=\"10\"/> <line x1=\"3\" x2=\"10\" y1=\"21\" y2=\"14\"/>",
  "instagram": "<rect width=\"20\" height=\"20\" x=\"2\" y=\"2\" rx=\"5\" ry=\"5\"/> <path d=\"M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z\"/> <line x1=\"17.5\" x2=\"17.51\" y1=\"6.5\" y2=\"6.5\"/>",
  "linkedin": "<path d=\"M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z\"/> <rect width=\"4\" height=\"12\" x=\"2\" y=\"9\"/> <circle cx=\"4\" cy=\"4\" r=\"2\"/>",
  "github": "<path d=\"M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4\"/> <path d=\"M9 18c-4.51 2-5-2-7-2\"/>",
  "dribbble": "<circle cx=\"12\" cy=\"12\" r=\"10\"/> <path d=\"M19.13 5.09C15.22 9.14 10 10.44 2.25 10.94\"/> <path d=\"M21.75 12.84c-6.62-1.41-12.14 1-16.38 6.32\"/> <path d=\"M8.56 2.75c4.37 6 6 9.42 8 17.72\"/>",
  "figma": "<path d=\"M5 5.5A3.5 3.5 0 0 1 8.5 2H12v7H8.5A3.5 3.5 0 0 1 5 5.5z\"/> <path d=\"M12 2h3.5a3.5 3.5 0 1 1 0 7H12V2z\"/> <path d=\"M12 12.5a3.5 3.5 0 1 1 7 0 3.5 3.5 0 1 1-7 0z\"/> <path d=\"M5 19.5A3.5 3.5 0 0 1 8.5 16H12v3.5a3.5 3.5 0 1 1-7 0z\"/> <path d=\"M5 12.5A3.5 3.5 0 0 1 8.5 9H12v7H8.5A3.5 3.5 0 0 1 5 12.5z\"/>"
};
const iconNames = Object.keys(ICONS);
function Icon({
  name,
  size = 20,
  strokeWidth = 1.5,
  color = 'currentColor',
  title,
  style,
  ...rest
}) {
  const body = ICONS[name];
  if (!body) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    role: title ? 'img' : undefined,
    "aria-hidden": title ? undefined : true,
    "aria-label": title,
    style: {
      flexShrink: 0,
      display: 'inline-block',
      verticalAlign: 'middle',
      ...style
    },
    dangerouslySetInnerHTML: {
      __html: (title ? '<title>' + title + '</title>' : '') + body
    }
  }, rest));
}
Object.assign(__ds_scope, { iconNames, Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    height: 'var(--control-height-sm)',
    padding: '0 14px',
    fontSize: 'var(--text-sm)',
    gap: 6,
    icon: 16
  },
  md: {
    height: 'var(--control-height-md)',
    padding: '0 18px',
    fontSize: 'var(--text-sm)',
    gap: 8,
    icon: 18
  },
  lg: {
    height: 'var(--control-height-lg)',
    padding: '0 26px',
    fontSize: 'var(--text-base)',
    gap: 10,
    icon: 20
  }
};
const VARIANTS = {
  primary: {
    base: {
      background: 'var(--color-primary)',
      color: 'var(--text-on-primary)',
      borderColor: 'var(--color-primary)'
    },
    hover: {
      background: 'var(--color-primary-hover)',
      borderColor: 'var(--color-primary-hover)'
    }
  },
  secondary: {
    base: {
      background: 'transparent',
      color: 'var(--text-primary)',
      borderColor: 'var(--border-strong)'
    },
    hover: {
      background: 'var(--ink-900)',
      color: 'var(--paper-100)',
      borderColor: 'var(--ink-900)'
    }
  },
  ghost: {
    base: {
      background: 'transparent',
      color: 'var(--text-primary)',
      borderColor: 'transparent'
    },
    hover: {
      background: 'var(--surface-press)'
    }
  },
  accent: {
    base: {
      background: 'var(--color-accent)',
      color: 'var(--text-on-accent)',
      borderColor: 'var(--color-accent)'
    },
    hover: {
      background: 'var(--red-400)',
      borderColor: 'var(--red-400)'
    }
  },
  highlight: {
    base: {
      background: 'var(--color-highlight)',
      color: 'var(--text-on-highlight)',
      borderColor: 'var(--color-highlight)'
    },
    hover: {
      background: 'var(--butter-500)',
      borderColor: 'var(--butter-500)'
    }
  },
  inverse: {
    base: {
      background: 'var(--paper-100)',
      color: 'var(--marine-800)',
      borderColor: 'var(--paper-100)'
    },
    hover: {
      background: 'var(--butter-400)',
      borderColor: 'var(--butter-400)'
    }
  }
};
function Button({
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  href,
  disabled = false,
  fullWidth = false,
  type = 'button',
  children,
  style,
  onClick,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? 'a' : 'button';
  const live = hover && !disabled;
  const css = {
    display: fullWidth ? 'flex' : 'inline-flex',
    width: fullWidth ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    height: s.height,
    padding: s.padding,
    borderRadius: 'var(--radius-pill)',
    borderWidth: 1,
    borderStyle: 'solid',
    fontFamily: 'var(--font-sans)',
    fontSize: s.fontSize,
    fontWeight: 'var(--weight-medium)',
    letterSpacing: '-0.005em',
    lineHeight: 1,
    whiteSpace: 'nowrap',
    textDecoration: 'none',
    cursor: disabled ? 'not-allowed' : 'pointer',
    userSelect: 'none',
    transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), transform var(--dur-instant) var(--ease-out)',
    ...v.base,
    ...(live ? v.hover : null),
    transform: press && !disabled ? 'translateY(1px)' : 'none',
    opacity: disabled ? 0.4 : 1,
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: disabled ? undefined : href,
    type: href ? undefined : type,
    disabled: href ? undefined : disabled,
    "aria-disabled": disabled || undefined,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setPress(false);
    },
    onMouseDown: () => setPress(true),
    onMouseUp: () => setPress(false),
    style: css
  }, rest), iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon,
    style: {
      transition: 'transform var(--dur-base) var(--ease-out)',
      transform: live ? 'translateX(3px)' : 'none'
    }
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    box: 32,
    icon: 16
  },
  md: {
    box: 40,
    icon: 18
  },
  lg: {
    box: 52,
    icon: 22
  }
};
const VARIANTS = {
  primary: {
    base: {
      background: 'var(--color-primary)',
      color: 'var(--text-on-primary)',
      borderColor: 'var(--color-primary)'
    },
    hover: {
      background: 'var(--color-primary-hover)'
    }
  },
  secondary: {
    base: {
      background: 'transparent',
      color: 'var(--text-primary)',
      borderColor: 'var(--border-strong)'
    },
    hover: {
      background: 'var(--ink-900)',
      color: 'var(--paper-100)'
    }
  },
  ghost: {
    base: {
      background: 'transparent',
      color: 'var(--text-primary)',
      borderColor: 'transparent'
    },
    hover: {
      background: 'var(--surface-press)'
    }
  },
  accent: {
    base: {
      background: 'var(--color-accent)',
      color: 'var(--text-on-accent)',
      borderColor: 'var(--color-accent)'
    },
    hover: {
      background: 'var(--red-400)'
    }
  },
  inverse: {
    base: {
      background: 'transparent',
      color: 'var(--paper-100)',
      borderColor: 'var(--border-inverse)'
    },
    hover: {
      background: 'var(--paper-100)',
      color: 'var(--marine-800)'
    }
  }
};
function IconButton({
  icon,
  label,
  variant = 'secondary',
  size = 'md',
  href,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const Tag = href ? 'a' : 'button';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    type: href ? undefined : 'button',
    "aria-label": label,
    title: label,
    disabled: href ? undefined : disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      width: s.box,
      height: s.box,
      padding: 0,
      borderRadius: 'var(--radius-pill)',
      borderWidth: 1,
      borderStyle: 'solid',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      textDecoration: 'none',
      transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
      ...v.base,
      ...(hover && !disabled ? v.hover : null),
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/Link.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  default: {
    color: 'var(--text-primary)',
    hover: 'var(--text-accent)'
  },
  brand: {
    color: 'var(--text-brand)',
    hover: 'var(--text-accent)'
  },
  muted: {
    color: 'var(--text-secondary)',
    hover: 'var(--text-primary)'
  },
  inverse: {
    color: 'var(--text-on-inverse)',
    hover: 'var(--butter-400)'
  }
};
function Link({
  href = '#',
  children,
  arrow,
  tone = 'default',
  underline = 'always',
  size,
  external,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const t = TONES[tone] || TONES.default;
  const arrowName = arrow === 'right' ? 'arrow-right' : arrow === 'up-right' ? 'arrow-up-right' : null;
  const showLine = underline === 'always' || underline === 'hover' && hover;
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    target: external ? '_blank' : undefined,
    rel: external ? 'noreferrer' : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.3em',
      color: hover ? t.hover : t.color,
      fontSize: size,
      fontFamily: 'inherit',
      textDecorationLine: showLine ? 'underline' : 'none',
      textDecorationThickness: '1px',
      textUnderlineOffset: '0.2em',
      transition: 'color var(--dur-fast) var(--ease-out)',
      cursor: 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", null, children), arrowName && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: arrowName,
    size: "0.95em",
    strokeWidth: 1.75,
    style: {
      transition: 'transform var(--dur-base) var(--ease-out)',
      transform: hover ? arrow === 'right' ? 'translateX(3px)' : 'translate(2px,-2px)' : 'none'
    }
  }));
}
Object.assign(__ds_scope, { Link });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Link.jsx", error: String((e && e.message) || e) }); }

// components/brand/Logo.jsx
try { (() => {
const TONES = {
  marine: ['var(--marine-700)', 'var(--red-500)'],
  ink: ['var(--ink-900)', 'var(--red-500)'],
  inverse: ['var(--paper-100)', 'var(--red-500)'],
  mono: ['currentColor', 'currentColor']
};
function Logo({
  variant = 'wordmark',
  tone = 'marine',
  size = 32,
  title = 'greenhueblues',
  style
}) {
  const [fg, dot] = TONES[tone] || TONES.marine;
  const base = {
    fontFamily: 'var(--font-sans)',
    fontWeight: 700,
    letterSpacing: '-0.035em',
    fontSize: size,
    lineHeight: variant === 'stacked' ? 0.86 : 1,
    color: fg,
    display: 'inline-block',
    whiteSpace: 'nowrap',
    fontStyle: 'normal',
    ...style
  };
  const Dot = /*#__PURE__*/React.createElement("span", {
    style: {
      color: dot
    }
  }, ".");
  if (variant === 'stacked') {
    return /*#__PURE__*/React.createElement("span", {
      role: "img",
      "aria-label": title,
      style: {
        ...base,
        display: 'inline-flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement("span", null, "green"), /*#__PURE__*/React.createElement("span", null, "hue"), /*#__PURE__*/React.createElement("span", null, "blues", Dot));
  }
  return /*#__PURE__*/React.createElement("span", {
    role: "img",
    "aria-label": title,
    style: base
  }, variant === 'monogram' ? 'ghb' : 'greenhueblues', Dot);
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
const SOFT = {
  neutral: ['var(--paper-200)', 'var(--ink-600)'],
  brand: ['var(--marine-50)', 'var(--marine-700)'],
  accent: ['var(--red-50)', 'var(--red-700)'],
  highlight: ['var(--butter-200)', 'var(--marine-800)'],
  success: ['var(--status-success-bg)', 'var(--green-700)'],
  warning: ['var(--status-warning-bg)', 'var(--status-warning)'],
  danger: ['var(--status-danger-bg)', 'var(--status-danger)']
};
const SOLID = {
  neutral: ['var(--ink-900)', 'var(--paper-100)'],
  brand: ['var(--marine-700)', 'var(--paper-100)'],
  accent: ['var(--red-500)', 'var(--ink-900)'],
  highlight: ['var(--butter-400)', 'var(--marine-800)'],
  success: ['var(--green-600)', 'var(--paper-0)'],
  warning: ['var(--butter-500)', 'var(--ink-900)'],
  danger: ['var(--red-700)', 'var(--paper-0)']
};
const DOT = {
  neutral: 'var(--ink-500)',
  brand: 'var(--marine-700)',
  accent: 'var(--red-500)',
  highlight: 'var(--butter-600)',
  success: 'var(--green-600)',
  warning: 'var(--butter-600)',
  danger: 'var(--red-600)'
};
function Badge({
  tone = 'neutral',
  variant = 'soft',
  dot = false,
  children,
  style
}) {
  const [bg, fg] = (variant === 'solid' ? SOLID : SOFT)[tone] || SOFT.neutral;
  const outline = variant === 'outline';
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 20,
      padding: '0 7px',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      fontWeight: 400,
      letterSpacing: '0.06em',
      textTransform: 'uppercase',
      lineHeight: 1,
      borderRadius: 'var(--radius-xs)',
      whiteSpace: 'nowrap',
      background: outline ? 'transparent' : bg,
      color: outline ? 'var(--text-secondary)' : fg,
      border: outline ? '1px solid var(--border-default)' : '1px solid transparent',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      background: variant === 'solid' ? 'currentColor' : DOT[tone],
      flexShrink: 0
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const MEDIA_TONES = {
  marine: {
    background: 'var(--marine-700)',
    color: 'var(--paper-100)'
  },
  butter: {
    background: 'var(--butter-400)',
    color: 'var(--marine-800)'
  },
  red: {
    background: 'var(--red-500)',
    color: 'var(--ink-900)'
  },
  paper: {
    background: 'var(--paper-200)',
    color: 'var(--ink-700)'
  },
  ink: {
    background: 'var(--ink-900)',
    color: 'var(--paper-100)'
  }
};
function Card({
  variant = 'project',
  media,
  mediaTone = 'paper',
  aspect = '4 / 3',
  eyebrow,
  title,
  meta,
  description,
  href,
  footer,
  children,
  style,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!(href || onClick);
  const Tag = href ? 'a' : 'div';
  const common = {
    href,
    onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  };
  if (variant === 'panel') {
    return /*#__PURE__*/React.createElement(Tag, _extends({}, common, {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 12,
        padding: 'var(--space-6)',
        textDecoration: 'none',
        color: 'inherit',
        background: 'var(--surface-card)',
        border: `1px solid ${hover && interactive ? 'var(--border-strong)' : 'var(--border-subtle)'}`,
        borderRadius: 'var(--radius-0)',
        cursor: interactive ? 'pointer' : undefined,
        transition: 'border-color var(--dur-fast) var(--ease-out)',
        ...style
      }
    }), eyebrow && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-xs)',
        letterSpacing: 'var(--tracking-caps)',
        textTransform: 'uppercase',
        color: 'var(--text-tertiary)'
      }
    }, eyebrow), title && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-lg)',
        fontWeight: 'var(--weight-medium)',
        letterSpacing: 'var(--tracking-tight)',
        lineHeight: 1.2,
        color: 'var(--text-primary)'
      }
    }, title), description && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-sm)',
        lineHeight: 1.55,
        color: 'var(--text-secondary)'
      }
    }, description), children, footer && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 'auto',
        paddingTop: 12
      }
    }, footer));
  }
  const tone = MEDIA_TONES[mediaTone] || MEDIA_TONES.paper;
  return /*#__PURE__*/React.createElement(Tag, _extends({}, common, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      textDecoration: 'none',
      color: 'inherit',
      cursor: interactive ? 'pointer' : undefined,
      minWidth: 0,
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: aspect,
      overflow: 'hidden',
      borderRadius: 'var(--radius-0)',
      ...tone
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      transform: hover && interactive ? 'scale(1.025)' : 'none',
      transition: 'transform var(--dur-reveal) var(--ease-out)'
    }
  }, media)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-md)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 1.25,
      color: 'var(--text-primary)',
      textDecorationLine: hover && interactive ? 'underline' : 'none',
      textDecorationThickness: '1px',
      textUnderlineOffset: '0.18em'
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      fontWeight: 400,
      color: 'var(--text-tertiary)',
      marginRight: 10,
      letterSpacing: 0
    }
  }, eyebrow), title), meta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)',
      whiteSpace: 'nowrap'
    }
  }, meta)), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 1.5,
      color: 'var(--text-secondary)'
    }
  }, description), children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/Tag.jsx
try { (() => {
function Tag({
  children,
  selected = false,
  onClick,
  onRemove,
  size = 'md',
  tone = 'default',
  disabled = false,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick && !disabled;
  const h = size === 'sm' ? 26 : 32;
  const inverse = tone === 'inverse';
  let bg = 'transparent',
    fg = inverse ? 'var(--paper-100)' : 'var(--text-primary)',
    bd = inverse ? 'var(--border-inverse)' : 'var(--border-default)';
  if (selected) {
    bg = inverse ? 'var(--paper-100)' : 'var(--ink-900)';
    fg = inverse ? 'var(--marine-800)' : 'var(--paper-100)';
    bd = bg;
  } else if (hover && interactive) {
    bd = inverse ? 'var(--paper-100)' : 'var(--border-strong)';
  }
  const Tag_ = onClick ? 'button' : 'span';
  return /*#__PURE__*/React.createElement(Tag_, {
    type: onClick ? 'button' : undefined,
    "aria-pressed": onClick ? selected : undefined,
    disabled: onClick ? disabled : undefined,
    onClick: interactive ? onClick : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: h,
      padding: onRemove ? '0 8px 0 12px' : '0 12px',
      fontFamily: 'var(--font-sans)',
      fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)',
      fontWeight: 400,
      lineHeight: 1,
      whiteSpace: 'nowrap',
      borderRadius: 'var(--radius-pill)',
      border: `1px solid ${bd}`,
      background: bg,
      color: fg,
      cursor: interactive ? 'pointer' : 'default',
      opacity: disabled ? 0.45 : 1,
      transition: 'background-color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, children, onRemove && /*#__PURE__*/React.createElement("span", {
    role: "button",
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onRemove();
    },
    style: {
      display: 'inline-flex',
      cursor: 'pointer',
      opacity: 0.7
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 14
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open = false,
  onClose,
  eyebrow,
  title,
  children,
  actions,
  width = 480,
  contained = false
}) {
  const [shown, setShown] = React.useState(open);
  React.useEffect(() => {
    if (open) {
      const r = requestAnimationFrame(() => setShown(true));
      return () => cancelAnimationFrame(r);
    }
    setShown(false);
  }, [open]);
  React.useEffect(() => {
    if (!open || !onClose) return;
    const onKey = e => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: contained ? 'absolute' : 'fixed',
      inset: 0,
      zIndex: 'var(--z-overlay)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 24,
      background: 'var(--scrim)',
      backdropFilter: 'blur(3px)',
      WebkitBackdropFilter: 'blur(3px)',
      opacity: shown ? 1 : 0,
      transition: 'opacity var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": typeof title === 'string' ? title : undefined,
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--surface-raised)',
      borderRadius: 'var(--radius-0)',
      boxShadow: 'var(--shadow-overlay)',
      display: 'flex',
      flexDirection: 'column',
      transform: shown ? 'none' : 'translateY(8px)',
      transition: 'transform var(--dur-slow) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16,
      padding: '20px 20px 0 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      paddingTop: 4
    }
  }, eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, eyebrow), title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: 'var(--tracking-tight)',
      lineHeight: 1.2
    }
  }, title)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    variant: "ghost",
    size: "sm",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 24px 24px',
      fontSize: 'var(--text-sm)',
      lineHeight: 1.55,
      color: 'var(--text-secondary)'
    }
  }, children), actions && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 8,
      padding: '16px 24px',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, actions)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const DOTS = {
  neutral: 'var(--paper-100)',
  success: '#5CC497',
  warning: 'var(--butter-400)',
  danger: 'var(--red-500)',
  accent: 'var(--red-500)'
};
function Toast({
  tone = 'neutral',
  title,
  message,
  actionLabel,
  onAction,
  onClose,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      width: '100%',
      maxWidth: 380,
      padding: '14px 14px 14px 16px',
      background: 'var(--ink-900)',
      color: 'var(--paper-100)',
      borderRadius: 'var(--radius-xs)',
      boxShadow: 'var(--shadow-overlay)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      marginTop: 6,
      flexShrink: 0,
      background: DOTS[tone] || DOTS.neutral
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, title && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      lineHeight: 1.4
    }
  }, title), message && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 1.45,
      color: 'var(--ink-300)'
    }
  }, message), actionLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      alignSelf: 'flex-start',
      marginTop: 6,
      padding: 0,
      border: 0,
      background: 'transparent',
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--butter-400)',
      textDecoration: 'underline',
      textUnderlineOffset: '0.2em',
      textDecorationThickness: '1px'
    }
  }, actionLabel)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      display: 'inline-flex',
      padding: 2,
      border: 0,
      background: 'transparent',
      color: 'var(--ink-300)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 16
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function Tooltip({
  label,
  placement = 'top',
  open,
  delay = 120,
  children
}) {
  const [hover, setHover] = React.useState(false);
  const timer = React.useRef(null);
  const show = open ?? hover;
  const enter = () => {
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setHover(true), delay);
  };
  const leave = () => {
    clearTimeout(timer.current);
    setHover(false);
  };
  React.useEffect(() => () => clearTimeout(timer.current), []);
  const pos = {
    top: {
      bottom: 'calc(100% + 8px)',
      left: '50%',
      transform: `translateX(-50%) translateY(${show ? 0 : 4}px)`
    },
    bottom: {
      top: 'calc(100% + 8px)',
      left: '50%',
      transform: `translateX(-50%) translateY(${show ? 0 : -4}px)`
    },
    left: {
      right: 'calc(100% + 8px)',
      top: '50%',
      transform: `translateY(-50%) translateX(${show ? 0 : 4}px)`
    },
    right: {
      left: 'calc(100% + 8px)',
      top: '50%',
      transform: `translateY(-50%) translateX(${show ? 0 : -4}px)`
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: enter,
    onMouseLeave: leave,
    onFocus: enter,
    onBlur: leave
  }, children, /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      ...pos,
      zIndex: 'var(--z-tooltip)',
      pointerEvents: 'none',
      whiteSpace: 'nowrap',
      padding: '6px 8px',
      borderRadius: 'var(--radius-xs)',
      background: 'var(--ink-900)',
      color: 'var(--paper-100)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-xs)',
      lineHeight: 1.2,
      fontWeight: 400,
      opacity: show ? 1 : 0,
      transition: 'opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)'
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  checked,
  defaultChecked = false,
  onChange,
  label,
  description,
  disabled = false,
  indeterminate = false,
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked ?? inner;
  const toggle = () => {
    if (disabled) return;
    const next = !isOn;
    if (checked === undefined) setInner(next);
    onChange && onChange(next);
  };
  const filled = isOn || indeterminate;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'flex-start',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "checkbox",
    "aria-checked": indeterminate ? 'mixed' : isOn,
    disabled: disabled,
    onClick: toggle,
    style: {
      width: 18,
      height: 18,
      marginTop: 2,
      flexShrink: 0,
      padding: 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-xs)',
      border: `1.5px solid ${filled ? 'var(--marine-700)' : 'var(--ink-500)'}`,
      background: filled ? 'var(--marine-700)' : 'var(--surface-raised)',
      color: 'var(--paper-100)',
      cursor: 'inherit',
      transition: 'background-color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)'
    }
  }, indeterminate ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "minus",
    size: 14,
    strokeWidth: 2.5
  }) : isOn ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 14,
    strokeWidth: 2.5
  }) : null), (label || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    },
    onClick: e => {
      e.preventDefault();
      toggle();
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 1.5,
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      lineHeight: 1.45,
      color: 'var(--text-tertiary)'
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
let uid = 0;
const useId = id => React.useMemo(() => id || 'ghb-in-' + ++uid, [id]);
function Field({
  id,
  label,
  hint,
  error,
  variant = 'box',
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: variant === 'line' ? 4 : 6,
      minWidth: 0
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: variant === 'line' ? {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    } : {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)'
    }
  }, label), children, (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      lineHeight: 1.4,
      color: error ? 'var(--status-danger)' : 'var(--text-tertiary)'
    }
  }, error || hint));
}
function fieldShell({
  variant,
  focused,
  error,
  disabled,
  multiline
}) {
  if (variant === 'line') {
    return {
      background: 'transparent',
      border: 0,
      borderRadius: 0,
      boxShadow: `inset 0 -${focused ? 2 : 1}px 0 ${error ? 'var(--red-600)' : focused ? 'var(--marine-700)' : 'var(--border-strong)'}`,
      minHeight: multiline ? undefined : 48,
      padding: multiline ? '8px 0' : '0',
      fontSize: 'var(--text-md)',
      opacity: disabled ? 0.45 : 1
    };
  }
  return {
    background: disabled ? 'var(--surface-sunken)' : 'var(--surface-raised)',
    border: `1px solid ${error ? 'var(--red-600)' : focused ? 'var(--marine-700)' : 'var(--border-default)'}`,
    borderRadius: 'var(--radius-xs)',
    boxShadow: focused ? `0 0 0 3px ${error ? 'var(--red-100)' : 'var(--marine-100)'}` : 'none',
    minHeight: multiline ? undefined : 'var(--control-height-md)',
    padding: multiline ? '10px 12px' : '0 12px',
    fontSize: 'var(--text-sm)',
    opacity: disabled ? 0.6 : 1
  };
}
function Input({
  id,
  label,
  hint,
  error,
  iconLeft,
  variant = 'box',
  multiline = false,
  rows = 4,
  disabled,
  style,
  onFocus,
  onBlur,
  ...rest
}) {
  const fid = useId(id);
  const [focused, setFocused] = React.useState(false);
  const shell = fieldShell({
    variant,
    focused,
    error,
    disabled,
    multiline
  });
  const Tag = multiline ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement(Field, {
    id: fid,
    label: label,
    hint: hint,
    error: error,
    variant: variant
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: multiline ? 'flex-start' : 'center',
      gap: 8,
      transition: 'box-shadow var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)',
      ...shell,
      ...style
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 16,
    color: "var(--text-tertiary)"
  }), /*#__PURE__*/React.createElement(Tag, _extends({
    id: fid,
    rows: multiline ? rows : undefined,
    disabled: disabled,
    "aria-invalid": error ? true : undefined,
    onFocus: e => {
      setFocused(true);
      onFocus && onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      onBlur && onBlur(e);
    },
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      padding: 0,
      margin: 0,
      font: 'inherit',
      fontFamily: 'var(--font-sans)',
      fontSize: 'inherit',
      color: 'var(--text-primary)',
      lineHeight: multiline ? 1.5 : undefined,
      height: multiline ? undefined : variant === 'line' ? 46 : 38,
      resize: multiline ? 'vertical' : undefined
    }
  }, rest))));
}
Object.assign(__ds_scope, { Field, fieldShell, Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function Radio({
  checked = false,
  onChange,
  label,
  description,
  disabled = false,
  value,
  name,
  style
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'flex-start',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "radio",
    "aria-checked": checked,
    name: name,
    value: value,
    disabled: disabled,
    onClick: () => !disabled && onChange && onChange(value),
    style: {
      width: 18,
      height: 18,
      marginTop: 2,
      flexShrink: 0,
      padding: 0,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '50%',
      border: `1.5px solid ${checked ? 'var(--marine-700)' : 'var(--ink-500)'}`,
      background: 'var(--surface-raised)',
      cursor: 'inherit',
      transition: 'border-color var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--marine-700)',
      transform: checked ? 'scale(1)' : 'scale(0)',
      transition: 'transform var(--dur-fast) var(--ease-out)'
    }
  })), (label || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    },
    onClick: e => {
      e.preventDefault();
      !disabled && onChange && onChange(value);
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      lineHeight: 1.5,
      color: 'var(--text-primary)'
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      lineHeight: 1.45,
      color: 'var(--text-tertiary)'
    }
  }, description)));
}
function RadioGroup({
  name,
  options = [],
  value,
  defaultValue,
  onChange,
  direction = 'column',
  label,
  disabled
}) {
  const [inner, setInner] = React.useState(defaultValue);
  const current = value ?? inner;
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  const pick = v => {
    if (value === undefined) setInner(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    role: "radiogroup",
    "aria-label": label,
    style: {
      display: 'flex',
      flexDirection: direction,
      gap: direction === 'row' ? 20 : 10,
      flexWrap: 'wrap'
    }
  }, opts.map(o => /*#__PURE__*/React.createElement(Radio, {
    key: o.value,
    name: name,
    value: o.value,
    label: o.label,
    description: o.description,
    checked: current === o.value,
    disabled: disabled || o.disabled,
    onChange: pick
  })));
}
Object.assign(__ds_scope, { Radio, RadioGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
let uid = 0;
function Select({
  id,
  label,
  hint,
  error,
  options = [],
  placeholder,
  variant = 'box',
  disabled,
  value,
  defaultValue,
  onChange,
  style,
  ...rest
}) {
  const fid = React.useMemo(() => id || 'ghb-sel-' + ++uid, [id]);
  const [focused, setFocused] = React.useState(false);
  const shell = __ds_scope.fieldShell({
    variant,
    focused,
    error,
    disabled
  });
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement(__ds_scope.Field, {
    id: fid,
    label: label,
    hint: hint,
    error: error,
    variant: variant
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      transition: 'box-shadow var(--dur-fast) var(--ease-out)',
      ...shell,
      paddingRight: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fid,
    disabled: disabled,
    value: value,
    defaultValue: value === undefined ? defaultValue ?? (placeholder ? '' : undefined) : undefined,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      font: 'inherit',
      fontFamily: 'var(--font-sans)',
      fontSize: 'inherit',
      color: 'var(--text-primary)',
      height: variant === 'line' ? 46 : 38,
      padding: '0 36px 0 0',
      margin: 0,
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--text-secondary)",
    style: {
      position: 'absolute',
      right: variant === 'line' ? 0 : 12,
      pointerEvents: 'none'
    }
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  checked,
  defaultChecked = false,
  onChange,
  label,
  disabled = false,
  size = 'md',
  style
}) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked ?? inner;
  const dims = size === 'sm' ? {
    w: 28,
    h: 16,
    k: 12
  } : {
    w: 36,
    h: 20,
    k: 16
  };
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInner(!isOn);
    onChange && onChange(!isOn);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": isOn,
    disabled: disabled,
    onClick: toggle,
    style: {
      position: 'relative',
      width: dims.w,
      height: dims.h,
      padding: 0,
      border: 0,
      flexShrink: 0,
      cursor: 'inherit',
      borderRadius: 'var(--radius-pill)',
      background: isOn ? 'var(--marine-700)' : 'var(--paper-400)',
      transition: 'background-color var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: (dims.h - dims.k) / 2,
      left: (dims.h - dims.k) / 2,
      width: dims.k,
      height: dims.k,
      borderRadius: '50%',
      background: 'var(--paper-0)',
      boxShadow: '0 1px 2px rgba(0,31,49,0.2)',
      transform: isOn ? `translateX(${dims.w - dims.h}px)` : 'none',
      transition: 'transform var(--dur-base) var(--ease-out)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    onClick: e => {
      e.preventDefault();
      toggle();
    },
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  variant = 'line',
  tone = 'default',
  style
}) {
  const list = items.map(i => typeof i === 'string' ? {
    id: i,
    label: i
  } : i);
  const [inner, setInner] = React.useState(defaultValue ?? (list[0] && list[0].id));
  const current = value ?? inner;
  const [hoverId, setHoverId] = React.useState(null);
  const pick = id => {
    if (value === undefined) setInner(id);
    onChange && onChange(id);
  };
  const inverse = tone === 'inverse';
  if (variant === 'segment') {
    return /*#__PURE__*/React.createElement("div", {
      role: "tablist",
      style: {
        display: 'inline-flex',
        gap: 2,
        padding: 3,
        borderRadius: 'var(--radius-pill)',
        background: inverse ? 'rgba(244,242,237,0.1)' : 'var(--surface-sunken)',
        ...style
      }
    }, list.map(t => {
      const on = t.id === current;
      return /*#__PURE__*/React.createElement("button", {
        key: t.id,
        role: "tab",
        type: "button",
        "aria-selected": on,
        onClick: () => pick(t.id),
        style: {
          height: 30,
          padding: '0 14px',
          border: 0,
          borderRadius: 'var(--radius-pill)',
          cursor: 'pointer',
          fontFamily: 'var(--font-sans)',
          fontSize: 'var(--text-sm)',
          fontWeight: on ? 'var(--weight-medium)' : 400,
          background: on ? inverse ? 'var(--paper-100)' : 'var(--surface-raised)' : 'transparent',
          color: on ? inverse ? 'var(--marine-800)' : 'var(--text-primary)' : inverse ? 'var(--text-on-inverse-muted)' : 'var(--text-secondary)',
          boxShadow: on && !inverse ? 'var(--shadow-pop)' : 'none',
          transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)'
        }
      }, t.label);
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: 'flex',
      gap: 28,
      borderBottom: `1px solid ${inverse ? 'var(--border-inverse)' : 'var(--border-subtle)'}`,
      overflowX: 'auto',
      overflowY: 'hidden',
      ...style
    }
  }, list.map(t => {
    const on = t.id === current;
    const hov = hoverId === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      role: "tab",
      type: "button",
      "aria-selected": on,
      onClick: () => pick(t.id),
      onMouseEnter: () => setHoverId(t.id),
      onMouseLeave: () => setHoverId(null),
      style: {
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'baseline',
        gap: 6,
        padding: '12px 0',
        marginBottom: -1,
        border: 0,
        background: 'transparent',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-base)',
        fontWeight: on ? 'var(--weight-medium)' : 400,
        whiteSpace: 'nowrap',
        color: on || hov ? inverse ? 'var(--paper-100)' : 'var(--text-primary)' : inverse ? 'var(--text-on-inverse-muted)' : 'var(--text-tertiary)',
        boxShadow: on ? `inset 0 -2px 0 ${inverse ? 'var(--paper-100)' : 'var(--ink-900)'}` : 'none',
        transition: 'color var(--dur-fast) var(--ease-out)'
      }
    }, t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-2xs)',
        fontWeight: 400,
        opacity: 0.8
      }
    }, t.count));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Art.jsx
try { (() => {
// Typographic placeholder art for project media. Replace with real photography when available.
const ART_TONES = {
  marine: ['var(--marine-700)', 'var(--paper-100)', 'var(--butter-400)'],
  butter: ['var(--butter-400)', 'var(--marine-800)', 'var(--red-500)'],
  red: ['var(--red-500)', 'var(--ink-900)', 'var(--paper-100)'],
  paper: ['var(--paper-200)', 'var(--marine-700)', 'var(--red-500)'],
  ink: ['var(--ink-900)', 'var(--paper-100)', 'var(--butter-400)']
};
function ProjectArt({
  project,
  fig
}) {
  const [bg, fg, ac] = ART_TONES[project.tone] || ART_TONES.paper;
  const big = {
    position: 'absolute',
    fontWeight: 500,
    letterSpacing: '-0.05em',
    lineHeight: 0.8,
    color: fg,
    whiteSpace: 'nowrap'
  };
  let body;
  if (project.comp === 'letter') {
    body = /*#__PURE__*/React.createElement("span", {
      style: {
        ...big,
        right: '-6cqw',
        bottom: '-14cqw',
        fontSize: '118cqw'
      }
    }, project.word);
  } else if (project.comp === 'number') {
    body = /*#__PURE__*/React.createElement("span", {
      style: {
        ...big,
        left: '5cqw',
        top: '14cqw',
        fontSize: '42cqw',
        fontWeight: 300
      }
    }, project.word);
  } else {
    body = /*#__PURE__*/React.createElement("span", {
      style: {
        ...big,
        left: '5cqw',
        bottom: '6cqw',
        fontSize: '24cqw'
      }
    }, project.word, /*#__PURE__*/React.createElement("span", {
      style: {
        color: ac
      }
    }, "."));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: bg,
      containerType: 'inline-size',
      overflow: 'hidden'
    }
  }, body, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '5cqw',
      top: '5cqw',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: fg,
      opacity: 0.75
    }
  }, "fig. ", fig || project.idx));
}
Object.assign(window, {
  ProjectArt
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Art.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactScreen.jsx
try { (() => {
const {
  Input: CInput,
  Select: CSelect,
  RadioGroup: CRadioGroup,
  Checkbox: CCheckbox,
  Tag: CTag,
  Button: CButton,
  Toast: CToast,
  Dialog: CDialog,
  Link: CLink
} = window.GreenhuebluesDesignSystem_653a8b;
function ContactScreen({
  go
}) {
  const [form, setForm] = React.useState({
    name: '',
    email: '',
    org: '',
    budget: '',
    timeline: 'q',
    brief: '',
    letter: false
  });
  const [tags, setTags] = React.useState(['Identity']);
  const [errors, setErrors] = React.useState({});
  const [confirm, setConfirm] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const set = k => e => setForm({
    ...form,
    [k]: e && e.target ? e.target.value : e
  });
  const toggle = t => setTags(tags.includes(t) ? tags.filter(x => x !== t) : [...tags, t]);
  const submit = e => {
    e.preventDefault();
    const er = {};
    if (!form.name) er.name = 'Tell us who you are.';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) er.email = 'Enter an email we can reply to.';
    setErrors(er);
    if (!Object.keys(er).length) setConfirm(true);
  };
  const send = () => {
    setConfirm(false);
    setToast(true);
    setForm({
      name: '',
      email: '',
      org: '',
      budget: '',
      timeline: 'q',
      brief: '',
      letter: false
    });
    setTimeout(() => setToast(false), 5000);
  };
  return /*#__PURE__*/React.createElement("main", {
    className: "ghb-wrap",
    style: {
      paddingTop: 'clamp(56px, 8vw, 120px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "g-12"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: 'span 4',
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "ghb-h1",
    style: {
      margin: 0
    }
  }, "Start a project", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")), /*#__PURE__*/React.createElement("p", {
    className: "ghb-body",
    style: {
      margin: 0,
      color: 'var(--text-secondary)',
      maxWidth: 340
    }
  }, "A few lines is enough. We read every brief and reply within two working days."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontSize: 15
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)',
      marginBottom: 4
    }
  }, "Or write to us"), /*#__PURE__*/React.createElement(CLink, {
    href: "#"
  }, "hello@greenhueblues.com"))), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    noValidate: true,
    style: {
      gridColumn: '6 / span 7',
      display: 'flex',
      flexDirection: 'column',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement(CInput, {
    variant: "line",
    label: "Name",
    value: form.name,
    onChange: set('name'),
    error: errors.name,
    placeholder: "Your name"
  }), /*#__PURE__*/React.createElement(CInput, {
    variant: "line",
    label: "Email",
    type: "email",
    value: form.email,
    onChange: set('email'),
    error: errors.email,
    placeholder: "you@organisation.org"
  }), /*#__PURE__*/React.createElement(CInput, {
    variant: "line",
    label: "Organisation",
    value: form.org,
    onChange: set('org'),
    placeholder: "Optional"
  }), /*#__PURE__*/React.createElement(CSelect, {
    variant: "line",
    label: "Budget",
    value: form.budget,
    onChange: set('budget'),
    placeholder: "Choose a range",
    options: ['Under 25k', '25–75k', '75k and up', 'Not sure yet']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "What do you need?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, ['Identity', 'Website', 'Software', 'Installation', 'Print', 'Not sure'].map(t => /*#__PURE__*/React.createElement(CTag, {
    key: t,
    selected: tags.includes(t),
    onClick: () => toggle(t)
  }, t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "When?"), /*#__PURE__*/React.createElement(CRadioGroup, {
    name: "timeline",
    direction: "row",
    value: form.timeline,
    onChange: set('timeline'),
    options: [{
      value: 'asap',
      label: 'As soon as possible'
    }, {
      value: 'q',
      label: 'Next quarter'
    }, {
      value: 'later',
      label: 'Later this year'
    }]
  })), /*#__PURE__*/React.createElement(CInput, {
    variant: "line",
    label: "Brief",
    multiline: true,
    rows: 4,
    value: form.brief,
    onChange: set('brief'),
    placeholder: "What are you making, and who is it for?"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(CCheckbox, {
    checked: form.letter,
    onChange: v => setForm({
      ...form,
      letter: v
    }),
    label: "Send me the studio letter",
    description: "Four times a year."
  }), /*#__PURE__*/React.createElement(CButton, {
    type: "submit",
    size: "lg",
    iconRight: "arrow-right"
  }, "Send brief")))), /*#__PURE__*/React.createElement(CDialog, {
    open: confirm,
    onClose: () => setConfirm(false),
    eyebrow: "Enquiry",
    title: "Send your brief?",
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CButton, {
      variant: "ghost",
      onClick: () => setConfirm(false)
    }, "Edit"), /*#__PURE__*/React.createElement(CButton, {
      onClick: send
    }, "Send"))
  }, "We'll reply to ", form.email || 'you', " within two working days", tags.length ? ` about ${tags.join(', ').toLowerCase()}` : '', "."), toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      left: 24,
      bottom: 24,
      zIndex: 'var(--z-toast)'
    }
  }, /*#__PURE__*/React.createElement(CToast, {
    tone: "success",
    title: "Brief sent",
    message: "Thanks. We'll be in touch soon.",
    onClose: () => setToast(false)
  })));
}
Object.assign(window, {
  ContactScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
const {
  Logo: FLogo,
  Link: FLink,
  Input: FInput,
  IconButton: FIconButton
} = window.GreenhuebluesDesignSystem_653a8b;
function SiteFooter({
  go
}) {
  const [email, setEmail] = React.useState('');
  const [joined, setJoined] = React.useState(false);
  const col = {
    display: 'flex',
    flexDirection: 'column',
    gap: 8,
    fontSize: 15
  };
  const label = {
    fontFamily: 'var(--font-mono)',
    fontSize: 11,
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    color: 'var(--text-on-inverse-muted)',
    marginBottom: 6
  };
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      paddingTop: 96,
      paddingBottom: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: label
  }, "Have a project in mind?"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      go({
        name: 'contact'
      });
    },
    style: {
      display: 'inline-block',
      color: 'var(--paper-100)',
      textDecoration: 'none',
      fontSize: 'clamp(40px, 7vw, 104px)',
      fontWeight: 500,
      letterSpacing: '-0.045em',
      lineHeight: 0.95
    },
    onMouseEnter: e => e.currentTarget.style.color = 'var(--butter-400)',
    onMouseLeave: e => e.currentTarget.style.color = 'var(--paper-100)'
  }, "hello@greenhueblues.com"), /*#__PURE__*/React.createElement("div", {
    className: "g-12",
    style: {
      marginTop: 96,
      paddingTop: 24,
      borderTop: '1px solid var(--border-inverse)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...col,
      gridColumn: 'span 3'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: label
  }, "Studio"), /*#__PURE__*/React.createElement("span", null, "Placeholder Street 12"), /*#__PURE__*/React.createElement("span", null, "City, Country")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...col,
      gridColumn: 'span 3'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: label
  }, "Elsewhere"), /*#__PURE__*/React.createElement(FLink, {
    href: "#",
    tone: "inverse",
    arrow: "up-right",
    underline: "hover"
  }, "Instagram"), /*#__PURE__*/React.createElement(FLink, {
    href: "#",
    tone: "inverse",
    arrow: "up-right",
    underline: "hover"
  }, "LinkedIn"), /*#__PURE__*/React.createElement(FLink, {
    href: "#",
    tone: "inverse",
    arrow: "up-right",
    underline: "hover"
  }, "GitHub")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...col,
      gridColumn: '8 / span 5'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: label
  }, "Studio letter"), joined ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 300
    }
  }, "Thanks. The next one goes out in spring", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      if (email) setJoined(true);
    },
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "email",
    value: email,
    onChange: e => setEmail(e.target.value),
    placeholder: "Email address",
    "aria-label": "Email address",
    style: {
      width: '100%',
      height: 44,
      background: 'transparent',
      border: 0,
      borderBottom: '1px solid var(--border-inverse)',
      color: 'var(--paper-100)',
      fontFamily: 'var(--font-sans)',
      fontSize: 18,
      outline: 'none'
    }
  })), /*#__PURE__*/React.createElement(FIconButton, {
    icon: "arrow-right",
    label: "Subscribe",
    variant: "inverse",
    type: "submit"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-on-inverse-muted)'
    }
  }, "Four times a year. New work, tools and reading."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: 64,
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(FLogo, {
    tone: "inverse",
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-on-inverse-muted)'
    }
  }, "\xA9 2026 greenhueblues"))));
}
Object.assign(window, {
  SiteFooter
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
const {
  Logo: HLogo,
  Button: HButton,
  IconButton: HIconButton
} = window.GreenhuebluesDesignSystem_653a8b;
function NavLink({
  active,
  onClick,
  children
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onClick();
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      fontSize: 15,
      textDecoration: 'none',
      color: active || hover ? 'var(--text-primary)' : 'var(--text-secondary)',
      fontWeight: active ? 500 : 400,
      transition: 'color var(--dur-fast) var(--ease-out)'
    }
  }, children, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)',
      opacity: active ? 1 : 0
    }
  }, "."));
}
function AnnouncementBar({
  onOpen,
  onClose
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--butter-400)',
      color: 'var(--marine-800)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      height: 36,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen();
    },
    style: {
      color: 'inherit',
      textDecoration: 'none',
      display: 'flex',
      gap: 10,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.08em',
      textTransform: 'uppercase'
    }
  }, "New"), /*#__PURE__*/React.createElement("span", null, "Tidal Index 2.0 is out \u2014 read the case study"), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2192")), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      border: 0,
      background: 'transparent',
      color: 'inherit',
      cursor: 'pointer',
      fontSize: 18,
      lineHeight: 1,
      padding: 4
    }
  }, "\xD7")));
}
function SiteHeader({
  route,
  go
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', on);
    return () => window.removeEventListener('scroll', on);
  }, []);
  const items = [['work', 'Work'], ['studio', 'Studio'], ['contact', 'Contact']];
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 'var(--z-header)',
      height: 'var(--header-height)',
      background: 'rgba(244,242,237,0.86)',
      backdropFilter: 'blur(var(--blur-header))',
      WebkitBackdropFilter: 'blur(var(--blur-header))',
      borderBottom: `1px solid ${scrolled ? 'var(--border-subtle)' : 'transparent'}`,
      transition: 'border-color var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      height: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    "aria-label": "greenhueblues home",
    onClick: e => {
      e.preventDefault();
      go({
        name: 'home'
      });
    },
    style: {
      textDecoration: 'none',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(HLogo, {
    size: 21
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "hide-sm",
    style: {
      display: 'flex',
      gap: 28
    }
  }, items.map(([id, label]) => /*#__PURE__*/React.createElement(NavLink, {
    key: id,
    active: route.name === id || id === 'work' && route.name === 'project',
    onClick: () => go({
      name: id
    })
  }, label))), /*#__PURE__*/React.createElement(HButton, {
    size: "sm",
    iconRight: "arrow-right",
    onClick: () => go({
      name: 'contact'
    })
  }, "Start a project"))));
}
Object.assign(window, {
  SiteHeader,
  AnnouncementBar
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
const {
  Button: HmButton,
  Card: HmCard,
  Link: HmLink
} = window.GreenhuebluesDesignSystem_653a8b;
function SectionHead({
  label,
  title,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      paddingBottom: 20,
      marginBottom: 32,
      borderBottom: '1px solid var(--border-strong)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, label), /*#__PURE__*/React.createElement("h2", {
    className: "ghb-h2",
    style: {
      margin: 0
    }
  }, title)), action);
}
function HomeScreen({
  go,
  openProject
}) {
  const P = window.GHB_PROJECTS;
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "hero-art",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("img", {
    className: "ha-shape",
    src: "../../assets/imagery/string-shape-butter.png",
    alt: ""
  }), /*#__PURE__*/React.createElement("img", {
    className: "ha-print",
    src: "../../assets/imagery/hanu-bhairava-print-ink.png",
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    className: "ha-rib"
  })), /*#__PURE__*/React.createElement("div", {
    className: "hero-text"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 700,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: 'clamp(48px, 7.2vw, 104px)',
      fontWeight: 500,
      letterSpacing: '-0.05em',
      lineHeight: 0.92
    }
  }, "Design and software for the art world", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '36px 0 0',
      maxWidth: 500,
      fontSize: 20,
      fontWeight: 300,
      lineHeight: 1.3,
      color: 'var(--text-secondary)'
    }
  }, "greenhueblues is a small studio making identities, websites and tools for galleries, archives and the people who run them."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 24,
      marginTop: 36,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(HmButton, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go({
      name: 'contact'
    })
  }, "Start a project"), /*#__PURE__*/React.createElement(HmLink, {
    href: "#",
    tone: "brand",
    arrow: "right",
    size: 16,
    onClick: e => {
      e.preventDefault();
      go({
        name: 'work'
      });
    }
  }, "View work")))))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'clamp(64px, 8vw, 120px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "g-feature",
    style: {
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(HmCard, {
    href: "#",
    onClick: e => {
      e && e.preventDefault && e.preventDefault();
      openProject(P[0]);
    },
    eyebrow: `(${P[0].idx})`,
    title: P[0].title,
    meta: `${P[0].year} — ${P[0].discipline}`,
    description: P[0].summary,
    aspect: "4 / 3",
    media: /*#__PURE__*/React.createElement(ProjectArt, {
      project: P[0]
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 'clamp(0px, 12vw, 180px)'
    }
  }, /*#__PURE__*/React.createElement(HmCard, {
    href: "#",
    onClick: e => {
      e && e.preventDefault && e.preventDefault();
      openProject(P[1]);
    },
    eyebrow: `(${P[1].idx})`,
    title: P[1].title,
    meta: `${P[1].year} — ${P[1].discipline}`,
    description: P[1].summary,
    aspect: "4 / 5",
    media: /*#__PURE__*/React.createElement(ProjectArt, {
      project: P[1]
    })
  }))), /*#__PURE__*/React.createElement("div", {
    className: "g-3",
    style: {
      marginTop: 72
    }
  }, P.slice(2, 5).map(p => /*#__PURE__*/React.createElement(HmCard, {
    key: p.id,
    href: "#",
    onClick: e => {
      e && e.preventDefault && e.preventDefault();
      openProject(p);
    },
    eyebrow: `(${p.idx})`,
    title: p.title,
    meta: `${p.year}`,
    aspect: "1 / 1",
    media: /*#__PURE__*/React.createElement(ProjectArt, {
      project: p
    })
  })))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    label: "Index",
    title: "Everything, in order",
    action: /*#__PURE__*/React.createElement(HmLink, {
      href: "#",
      arrow: "right",
      onClick: e => {
        e.preventDefault();
        go({
          name: 'work',
          view: 'list'
        });
      }
    }, "All work")
  }), /*#__PURE__*/React.createElement(IndexList, {
    projects: P.slice(0, 6),
    onOpen: openProject
  })), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    label: "What we do",
    title: "Three disciplines, one team",
    action: /*#__PURE__*/React.createElement(HmLink, {
      href: "#",
      arrow: "right",
      onClick: e => {
        e.preventDefault();
        go({
          name: 'studio'
        });
      }
    }, "The studio")
  }), /*#__PURE__*/React.createElement("div", {
    className: "g-3",
    style: {
      gap: 'var(--grid-gutter)'
    }
  }, window.GHB_SERVICES.map(s => /*#__PURE__*/React.createElement(HmCard, {
    key: s.n,
    variant: "panel",
    eyebrow: s.n,
    title: s.title,
    description: s.body,
    style: {
      minHeight: 220
    }
  })))));
}
Object.assign(window, {
  HomeScreen,
  SectionHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/IndexList.jsx
try { (() => {
const {
  Icon: LIcon
} = window.GreenhuebluesDesignSystem_653a8b;
function IndexRow({
  p,
  onOpen
}) {
  const [hover, setHover] = React.useState(false);
  const cell = {
    fontSize: 15,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis'
  };
  return /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onOpen(p);
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'grid',
      gridTemplateColumns: '56px minmax(0,2fr) minmax(0,1.6fr) 140px 56px 24px',
      alignItems: 'center',
      gap: 16,
      padding: '14px 0',
      borderBottom: '1px solid var(--border-subtle)',
      color: 'var(--text-primary)',
      textDecoration: 'none',
      background: hover ? 'var(--butter-300)' : 'transparent',
      boxShadow: hover ? '-8px 0 0 var(--butter-300), 8px 0 0 var(--butter-300)' : 'none',
      transition: 'background-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-tertiary)'
    }
  }, "(", p.idx, ")"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...cell,
      fontSize: 18,
      fontWeight: 500,
      letterSpacing: '-0.015em'
    }
  }, p.title), /*#__PURE__*/React.createElement("span", {
    className: "hide-sm",
    style: {
      ...cell,
      color: 'var(--text-secondary)'
    }
  }, p.client), /*#__PURE__*/React.createElement("span", {
    className: "hide-sm",
    style: {
      ...cell,
      color: 'var(--text-secondary)'
    }
  }, p.discipline), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-tertiary)'
    }
  }, p.year), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      transform: hover ? 'translateX(0)' : 'translateX(-6px)',
      opacity: hover ? 1 : 0,
      transition: 'all var(--dur-base) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(LIcon, {
    name: "arrow-right",
    size: 18
  })));
}
function IndexList({
  projects,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '56px minmax(0,2fr) minmax(0,1.6fr) 140px 56px 24px',
      gap: 16,
      paddingBottom: 10,
      borderBottom: '1px solid var(--border-strong)',
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "No."), /*#__PURE__*/React.createElement("span", null, "Project"), /*#__PURE__*/React.createElement("span", {
    className: "hide-sm"
  }, "Client"), /*#__PURE__*/React.createElement("span", {
    className: "hide-sm"
  }, "Discipline"), /*#__PURE__*/React.createElement("span", null, "Year"), /*#__PURE__*/React.createElement("span", null)), projects.map(p => /*#__PURE__*/React.createElement(IndexRow, {
    key: p.id,
    p: p,
    onOpen: onOpen
  })));
}
Object.assign(window, {
  IndexList
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/IndexList.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProjectScreen.jsx
try { (() => {
const {
  Link: PLink,
  Badge: PBadge,
  Tag: PTag,
  Button: PButton
} = window.GreenhuebluesDesignSystem_653a8b;
function MetaItem({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      paddingTop: 12,
      borderTop: '1px solid var(--border-strong)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15
    }
  }, children));
}
function ProjectScreen({
  route,
  go,
  openProject
}) {
  const all = window.GHB_PROJECTS;
  const i = Math.max(0, all.findIndex(p => p.id === route.id));
  const p = all[i];
  const next = all[(i + 1) % all.length];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      paddingTop: 40
    }
  }, /*#__PURE__*/React.createElement(PLink, {
    href: "#",
    tone: "muted",
    underline: "hover",
    onClick: e => {
      e.preventDefault();
      go({
        name: 'work'
      });
    }
  }, "\u2190 All work"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginTop: 'clamp(40px, 6vw, 88px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, "(", p.idx, ")"), p.year >= 2026 && /*#__PURE__*/React.createElement(PBadge, {
    tone: "highlight"
  }, "New")), /*#__PURE__*/React.createElement("h1", {
    className: "ghb-h1",
    style: {
      margin: '16px 0 0',
      maxWidth: '12em'
    }
  }, p.title, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")), /*#__PURE__*/React.createElement("div", {
    className: "g-12",
    style: {
      marginTop: 48
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "ghb-lede",
    style: {
      gridColumn: 'span 7',
      margin: 0
    }
  }, p.summary), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '9 / span 4',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(MetaItem, {
    label: "Client"
  }, p.client), /*#__PURE__*/React.createElement(MetaItem, {
    label: "Year"
  }, p.year), /*#__PURE__*/React.createElement(MetaItem, {
    label: "Discipline"
  }, p.discipline)))), /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      marginTop: 72
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '16 / 9'
    }
  }, /*#__PURE__*/React.createElement(ProjectArt, {
    project: p,
    fig: "01"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap g-12",
    style: {
      marginTop: 96
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: 'span 3'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "The brief")), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '4 / span 6',
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "ghb-body",
    style: {
      margin: 0
    }
  }, "Placeholder case-study copy. Describe the client, the problem as they put it, and what changed once the work was in use. Keep each paragraph to one idea and let the images carry the rest."), /*#__PURE__*/React.createElement("p", {
    className: "ghb-body",
    style: {
      margin: 0,
      color: 'var(--text-secondary)'
    }
  }, "Credit collaborators by name. Link to anything that is live."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginTop: 8
    }
  }, [p.discipline, 'Art direction', 'Web'].map(t => /*#__PURE__*/React.createElement(PTag, {
    key: t,
    size: "sm"
  }, t))))), /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      marginTop: 96,
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)',
      gap: 'var(--grid-gutter)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '4 / 5'
    }
  }, /*#__PURE__*/React.createElement(ProjectArt, {
    project: {
      ...p,
      comp: 'letter',
      word: p.title[0]
    },
    fig: "02"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '4 / 5'
    }
  }, /*#__PURE__*/React.createElement(ProjectArt, {
    project: {
      ...p,
      tone: 'paper',
      comp: 'number',
      word: p.idx
    },
    fig: "03"
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      paddingTop: 20,
      borderTop: '1px solid var(--border-strong)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "Next project"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "ghb-h2",
    onClick: e => {
      e.preventDefault();
      openProject(next);
    },
    style: {
      color: 'var(--text-primary)',
      textDecoration: 'none'
    }
  }, next.title)), /*#__PURE__*/React.createElement(PButton, {
    variant: "secondary",
    iconRight: "arrow-right",
    onClick: () => openProject(next)
  }, "Next"))));
}
Object.assign(window, {
  ProjectScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProjectScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/StudioScreen.jsx
try { (() => {
const {
  Card: SCard,
  Button: SButton
} = window.GreenhuebluesDesignSystem_653a8b;
function StudioScreen({
  go
}) {
  const clients = ['Harbour Maritime Museum', 'Kunsthal Noord', 'The Long Room Gallery', 'Lumen Festival', 'Atlas Editions', 'City Archive', 'Radio Kunst'];
  const principles = [['Small teams', 'Every project is led by the people who design and build it. No hand-offs between departments.'], ['Tools as craft', 'We write software the way we set type: carefully, and for the people who will use it every day.'], ['Room for the work', 'Our clients show art. The design should frame it, then get out of the way.']];
  return /*#__PURE__*/React.createElement("main", null, /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      paddingTop: 'clamp(56px, 8vw, 120px)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "ghb-h1",
    style: {
      margin: 0
    }
  }, "Studio", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")), /*#__PURE__*/React.createElement("div", {
    className: "g-12",
    style: {
      marginTop: 56
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "ghb-lede",
    style: {
      gridColumn: '1 / span 8',
      margin: 0,
      fontSize: 'clamp(24px, 2.6vw, 36px)'
    }
  }, "We are designers and developers working on one floor. Half of our work is identity and editorial design; the other half is software that keeps creative organisations running."))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    label: "Approach",
    title: "How we work"
  }), /*#__PURE__*/React.createElement("div", {
    className: "g-3",
    style: {
      gap: 'var(--grid-gutter)'
    }
  }, principles.map(([t, b], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-tertiary)'
    }
  }, "(", String(i + 1).padStart(2, '0'), ")"), /*#__PURE__*/React.createElement("h3", {
    className: "ghb-h3",
    style: {
      margin: 0
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    className: "ghb-body",
    style: {
      margin: 0,
      color: 'var(--text-secondary)'
    }
  }, b))))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement(SectionHead, {
    label: "Services",
    title: "What you can hire us for"
  }), /*#__PURE__*/React.createElement("div", {
    className: "g-3",
    style: {
      gap: 'var(--grid-gutter)'
    }
  }, window.GHB_SERVICES.map(s => /*#__PURE__*/React.createElement(SCard, {
    key: s.n,
    variant: "panel",
    eyebrow: s.n,
    title: s.title,
    description: s.body,
    style: {
      minHeight: 200
    }
  })))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap g-12",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: 'span 4'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ghb-eyebrow",
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "Selected clients")), /*#__PURE__*/React.createElement("ul", {
    style: {
      gridColumn: '5 / span 8',
      listStyle: 'none',
      margin: 0,
      padding: 0,
      columns: 2,
      columnGap: 'var(--grid-gutter)'
    }
  }, clients.map(c => /*#__PURE__*/React.createElement("li", {
    key: c,
    style: {
      fontSize: 22,
      letterSpacing: '-0.015em',
      lineHeight: 1.5,
      breakInside: 'avoid'
    }
  }, c)))), /*#__PURE__*/React.createElement("section", {
    className: "ghb-wrap",
    style: {
      marginTop: 'var(--section-gap)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--butter-400)',
      color: 'var(--marine-800)',
      padding: 'clamp(32px, 5vw, 64px)',
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "ghb-h2",
    style: {
      margin: 0,
      maxWidth: '14em'
    }
  }, "We take on four or five new projects a year."), /*#__PURE__*/React.createElement(SButton, {
    size: "lg",
    iconRight: "arrow-right",
    onClick: () => go({
      name: 'contact'
    })
  }, "Start a project"))));
}
Object.assign(window, {
  StudioScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/StudioScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/WorkScreen.jsx
try { (() => {
const {
  Tabs: WTabs,
  Card: WCard
} = window.GreenhuebluesDesignSystem_653a8b;
function WorkScreen({
  route,
  go,
  openProject
}) {
  const all = window.GHB_PROJECTS;
  const [filter, setFilter] = React.useState('all');
  const [view, setView] = React.useState(route.view === 'list' ? 'List' : 'Grid');
  const disciplines = ['Identity', 'Software', 'Installation', 'Print'];
  const items = [{
    id: 'all',
    label: 'All',
    count: all.length
  }, ...disciplines.map(d => ({
    id: d,
    label: d,
    count: all.filter(p => p.discipline === d).length
  }))];
  const list = filter === 'all' ? all : all.filter(p => p.discipline === filter);
  return /*#__PURE__*/React.createElement("main", {
    className: "ghb-wrap",
    style: {
      paddingTop: 'clamp(56px, 8vw, 120px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "ghb-h1",
    style: {
      margin: 0
    }
  }, "Work", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--red-500)'
    }
  }, ".")), /*#__PURE__*/React.createElement("p", {
    className: "ghb-small",
    style: {
      margin: 0,
      maxWidth: 360,
      color: 'var(--text-secondary)'
    }
  }, "Selected projects from 2022 to now. Most started with a short conversation.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 24,
      marginTop: 48,
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement(WTabs, {
    items: items,
    value: filter,
    onChange: setFilter,
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(WTabs, {
    variant: "segment",
    items: ['Grid', 'List'],
    value: view,
    onChange: setView,
    style: {
      marginBottom: 8
    }
  })), view === 'Grid' ? /*#__PURE__*/React.createElement("div", {
    className: "g-3"
  }, list.map((p, i) => /*#__PURE__*/React.createElement(WCard, {
    key: p.id,
    href: "#",
    onClick: e => {
      e && e.preventDefault && e.preventDefault();
      openProject(p);
    },
    eyebrow: `(${p.idx})`,
    title: p.title,
    meta: `${p.year} — ${p.discipline}`,
    aspect: i % 3 === 1 ? '4 / 5' : '4 / 3',
    media: /*#__PURE__*/React.createElement(ProjectArt, {
      project: p
    })
  }))) : /*#__PURE__*/React.createElement(IndexList, {
    projects: list,
    onOpen: openProject
  }));
}
Object.assign(window, {
  WorkScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/WorkScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/data.js
try { (() => {
window.GHB_PROJECTS = [{
  id: 'tidal-index',
  idx: '01',
  title: 'Tidal Index',
  client: 'Harbour Maritime Museum',
  discipline: 'Software',
  year: 2026,
  tone: 'marine',
  comp: 'word',
  word: 'Tidal',
  summary: 'Collection software and public catalogue for 40,000 maritime objects.'
}, {
  id: 'soft-machines',
  idx: '02',
  title: 'Soft Machines',
  client: 'Kunsthal Noord',
  discipline: 'Identity',
  year: 2025,
  tone: 'butter',
  comp: 'letter',
  word: 'S',
  summary: 'Identity and exhibition graphics for a survey of early computer art.'
}, {
  id: 'long-room',
  idx: '03',
  title: 'The Long Room',
  client: 'The Long Room Gallery',
  discipline: 'Identity',
  year: 2025,
  tone: 'paper',
  comp: 'word',
  word: 'Long',
  summary: 'A name, identity and website for a gallery in a former rope works.'
}, {
  id: 'field-notes',
  idx: '04',
  title: 'Field Notes Engine',
  client: 'Self-initiated',
  discipline: 'Software',
  year: 2024,
  tone: 'ink',
  comp: 'number',
  word: '024',
  summary: 'A generative print system that turns field recordings into posters.'
}, {
  id: 'red-hour',
  idx: '05',
  title: 'Red Hour',
  client: 'Lumen Festival',
  discipline: 'Installation',
  year: 2024,
  tone: 'red',
  comp: 'letter',
  word: 'R',
  summary: 'A light installation timed to the last hour before sunset.'
}, {
  id: 'paper-weather',
  idx: '06',
  title: 'Paper Weather',
  client: 'Atlas Editions',
  discipline: 'Print',
  year: 2023,
  tone: 'butter',
  comp: 'word',
  word: 'Weather',
  summary: 'A 240-page book of meteorological drawings, typeset in one weight.'
}, {
  id: 'small-things',
  idx: '07',
  title: 'Atlas of Small Things',
  client: 'City Archive',
  discipline: 'Software',
  year: 2023,
  tone: 'marine',
  comp: 'number',
  word: '07',
  summary: 'An archive website built around a single, very long index.'
}, {
  id: 'quiet-signal',
  idx: '08',
  title: 'Quiet Signal',
  client: 'Radio Kunst',
  discipline: 'Installation',
  year: 2022,
  tone: 'ink',
  comp: 'word',
  word: 'Quiet',
  summary: 'A sound installation and its printed programme.'
}];
window.GHB_SERVICES = [{
  n: '01',
  title: 'Identity',
  body: 'Names, marks, type systems and the guidelines that keep them consistent across print and screen.'
}, {
  n: '02',
  title: 'Websites',
  body: 'Editorial sites for galleries, archives and publishers, designed and built in-house.'
}, {
  n: '03',
  title: 'Software',
  body: 'Collection tools, generative systems and internal apps for creative teams.'
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/data.js", error: String((e && e.message) || e) }); }

// ui_kits/website/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/image-slot.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Link = __ds_scope.Link;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.RadioGroup = __ds_scope.RadioGroup;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
