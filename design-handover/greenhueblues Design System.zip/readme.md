# greenhueblues — Design System

**greenhueblues** is a small, niche studio working between art/graphic design and software. This system supports the **revamp** of its brand and website: a minimal, clean, finished look that frames the work rather than competing with it.

## Sources
- `uploads/Neue-Haas-Unica-Pro/` — 18 TTFs of **Neue Haas Unica Pro** (UltraLight → XBlack, roman + italic), supplied by the client. Copied to `fonts/`.
- Brief (chat): primary **Marine Blue #003B5C**, accent **Bright Red #FF3B30**, highlight **Butter Yellow #FFD966**; "minimal clean finish website revamp for a niche art design studio / software company"; the client asked for help creating a logo.
- No existing website, codebase, Figma, logo or imagery was provided. Everything else here (neutrals, scales, logo, components, website) is a **proposal** derived from those three colours and the typeface.

## Products / surfaces
- **Studio website** — the only surface defined so far. See `ui_kits/website/`.

---

## CONTENT FUNDAMENTALS

**Voice.** Plain, specific, quietly confident. A studio talking to peers in museums, galleries and creative teams, not selling to them. Say what the work is and who it was for; let images carry the adjectives.

- **Person.** "We" for the studio, "you" for the reader. Never "our team of experts", never "I".
- **Casing.** Sentence case for every heading, button and nav item ("Start a project", "Selected work"). The wordmark is always lowercase: **greenhueblues** — one word, never "GreenHueBlues" or "Green Hue Blues". When the name opens a sentence it stays lowercase.
- **Punctuation.** Display headlines and page titles end with a full stop, and that full stop is **red** (`--red-500`) — the brand's signature: "Work.", "Start a project.". Body copy uses normal punctuation. En dash for ranges (2022–2026), em dash with spaces in meta (2026 — Identity).
- **Length.** Headlines ≤ 8 words. Ledes one sentence. Paragraphs one idea. Buttons 1–3 words, verb first.
- **Numbers.** Projects are indexed in brackets, in mono: (01), (02). Years as four digits. Figures captioned "fig. 01".
- **Emoji.** Never. No exclamation marks in UI.
- **Avoid.** Superlatives ("world-class", "cutting-edge"), "solutions", "passionate", "elevate", rhetorical questions in body copy.

Examples
- Hero: "Design and software for the art world."
- Lede: "greenhueblues is a small studio making identities, websites and tools for galleries, archives and the people who run them."
- CTA: "Start a project" · "View work" · "All work →"
- Form helper: "A few lines is enough. We read every brief and reply within two working days."
- Toast: "Brief sent — Thanks. We'll be in touch soon."
- Error: "Enter an email we can reply to." (tell people what to do, not what they did wrong)

---

## VISUAL FOUNDATIONS

**Overall vibe.** Swiss-leaning editorial minimalism on warm paper. Big confident type, hairline rules, lots of air, three flat brand colours used with restraint. It should feel printed: considered margins, no glossy UI effects.

**Colour.** (`tokens/colors.css`)
- Page is **paper** `#F4F2ED` (warm stock), text is **ink** `#0F1B23` (cool, marine-tinted). The warm/cool pairing is deliberate.
- **Marine** `#003B5C` is the brand colour: wordmark, primary buttons, focus of attention, full inverse sections (footer).
- **Red** `#FF3B30` is a full stop, not a fill: logo dot, headline full stops, focus rings, hover on links (as `--red-700` for small text), the occasional "accent" button. Target ~2% of any layout.
- **Butter** `#FFD966` is a highlighter: `::selection`, `<mark>`, index-row hover, announcement bar, one call-to-action block per page.
- Text on red uses **ink** (white on #FF3B30 fails contrast). Red as small text uses `--red-700`.
- Proportion guide: 58 paper · 20 ink · 15 marine · 5 butter · 2 red.

**Type.** (`tokens/typography.css`) Neue Haas Unica Pro throughout. House weights: Light 300 (ledes), Regular 400 (body), Medium 500 (display + headings), Bold 700 (wordmark only). The other five weights exist for posters and special cases. Display is huge (up to 168px) with tight tracking (−0.05em) and 0.92 leading; headings −0.02 to −0.035em. **DM Mono** (Google Fonts) is the secondary voice for indexes, meta, eyebrows (uppercase, +0.08em) and code. True italics for titles of works only.

**Spacing & layout.** (`tokens/spacing.css`) 4px base, scale to 192px. 12-column grid, 24px gutter, page margin `clamp(20px, 4vw, 56px)`, max 1440px. Sections separated by `clamp(96px, 12vw, 192px)`. Asymmetric compositions (7/5 splits, offset columns, text starting on column 6 or 9) over centred stacks. Measure ~62ch.

**Backgrounds.** Flat colour only: paper, marine (inverse), butter (one block). **No gradients, no textures, no patterns, no blobs.** Imagery is full-bleed inside its frame, square-cornered. When imagery is missing, use flat tone fields with oversized type (see `ui_kits/website/Art.jsx`) — never stock photos.

**Imagery vibe.** (No imagery provided yet.) Recommended: documentary photography of work in situ, natural light, slightly warm, low saturation so the brand colours stay the loudest thing; product screenshots shown flat, no device mockups.

**Corners.** Square (0) for content: images, cards, dialogs, sections. **Pill** for controls: buttons, icon buttons, tags, switches, segmented tabs. 2px for small fields: inputs, badges, toasts, tooltips. 4/8px exist but are rarely used.

**Borders & rules.** Hairlines do the structural work. 1px `--border-subtle` for dividers, `--border-default` for fields, 1px ink `--border-strong` above section heads and meta, 2px ink for the active tab.

**Shadows.** Flat by default. `--shadow-pop` for small floating things (segment thumb, menus), `--shadow-overlay` for dialogs and toasts. No inner shadows. No coloured glows.

**Cards.** Project card = square media frame + caption below (title in Medium 18, mono index before, mono meta right). No border, no shadow, no background. Panel card = paper-50 fill + 1px subtle border, square, 24px padding; border turns ink on hover when interactive.

**Hover.** Links: colour → red-700 (butter on marine), underline stays. Secondary buttons invert to ink fill. Primary darkens to marine-800. Trailing arrows nudge 3px right (up-right arrows nudge diagonally). Project media zooms 2.5% over 680ms; title underlines. Index rows fill butter-300.

**Press.** Buttons translate 1px down. No scale-down, no ripples.

**Focus.** 2px red outline with 2px offset (`:focus-visible`). Fields: marine border + 3px marine-100 halo.

**Motion.** (`tokens/effects.css`) One curve, `--ease-out` cubic-bezier(.2,.7,.1,1); `--ease-in-out` for things that move and return. Durations 80/140/220/380/680ms. Fades and short translates (4–8px). Nothing bounces, nothing spins except the loader. Respect `prefers-reduced-motion`.

**Transparency & blur.** Only two places: the sticky header (paper at 86% + 14px backdrop blur) and the dialog scrim (marine-900 at 48% + 3px blur).

**Fixed elements.** Sticky header (64px). Optional butter announcement bar above it (36px, dismissible). Toasts bottom-left, 24px inset.

---

## ICONOGRAPHY

- **No icon set was provided.** Substitute: **Lucide** (ISC), chosen because its geometric outline style and round caps sit well beside Unica. 65 icons copied from `lucide-static@0.468.0` into `assets/icons/` and embedded in the `Icon` component. Need more? Copy from the same package version: `https://unpkg.com/lucide-static@0.468.0/icons/<name>.svg`.
- **Style.** Outline only, **1.5 stroke** (raw SVGs ship at 2; set `stroke-width="1.5"` when inlining), round caps/joins, `currentColor`. 16–24px. Never filled or duotone.
- **Usage.** Sparse. Arrows do most of the work (`arrow-right` internal, `arrow-up-right` external). Utility icons (search, close, menu, download) in controls only. No icons decorating headings or service lists — use mono numerals `01 02 03` instead.
- **Emoji.** Never. **Unicode.** `→` and `×` are acceptable inline in the announcement bar and plain-text contexts; `—` and `–` per the punctuation rules.
- **Social.** Lucide's `instagram`, `linkedin`, `github`, `dribbble`, `figma` are included, but text links with ↗ are preferred in the footer.

---

## LOGO

The client had no logo and asked for help, so a typographic wordmark was created **from the supplied typeface** (outlined from Neue Haas Unica Pro Bold with opentype.js, no hand drawing):

- **Wordmark** `greenhueblues.` — lowercase, Bold 700, −0.035em tracking, red full stop. Primary.
- **Stacked** `green / hue / blues.` — square formats, covers, social avatars at large sizes.
- **Monogram** `ghb.` — favicon, small avatars, tight spaces.
- Tones: marine on paper (default), paper on marine/ink (`-inverse`), ink, mono.
- Clear space = x-height on every side. Minimum 96px wide (wordmark), 16px tall (monogram).
- Explorations at Medium and Black weights are in `assets/logo/explore-*.svg` and the "Wordmark weights" card.
- Don't: recolour the dot, drop the dot (except mono one-colour print), capitalise, add a symbol, outline, or set it in another font.

---

## INDEX

```
styles.css            entry point — @imports only
tokens/               fonts.css · colors.css · typography.css · spacing.css · effects.css · base.css
fonts/                Neue Haas Unica Pro TTFs (18)
assets/logo/          wordmark, stacked, monogram (+ inverse/ink/mono), explorations — outlined SVG
assets/icons/         65 Lucide SVGs
assets/imagery/       gallery-niche photo, hero print (hanu-bhairava-print-ink.png), butter string-art
guidelines/           foundation specimen cards (Colors, Type, Spacing, Brand)
components/           brand/ actions/ forms/ display/ navigation/ feedback/ — one card per folder
ui_kits/website/      studio website click-through (index.html + screens)
thumbnail.html        homepage tile
SKILL.md              Agent Skill entry
```

### Components
Namespace in cards: `window.GreenhuebluesDesignSystem_653a8b`.
- **brand/** — `Logo`, `Icon`
- **actions/** — `Button`, `IconButton`, `Link`
- **forms/** — `Input` (+ `Field`), `Select`, `Checkbox`, `Radio` (+ `RadioGroup`), `Switch`
- **display/** — `Card`, `Badge`, `Tag`
- **navigation/** — `Tabs`
- **feedback/** — `Dialog`, `Toast`, `Tooltip`

No source defined a component inventory, so this is a standard set sized to a studio website.

**Intentional additions** (beyond the standard set)
- `Logo` — renders the wordmark live in the webfont so it never drifts from the SVGs.
- `Icon` — wraps the copied Lucide subset at the house stroke weight.
- `Link` — text links with arrows are the primary navigation pattern on the site.
- `RadioGroup` — manages state for `Radio`, which is controlled-only.
- `Field` — shared label/hint/error wrapper for `Input` and `Select`.

### UI kits
- `ui_kits/website/` — Home, Work, Project, Studio, Contact.

## Caveats
- DM Mono is an **addition**, not a substitution (no mono was supplied). Swap `--font-mono` if the studio licenses one.
- Neutral, status and tint scales are derived, not supplied.
- All project names, clients, address and copy in the UI kit are placeholders.
