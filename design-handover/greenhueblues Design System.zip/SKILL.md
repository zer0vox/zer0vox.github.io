---
name: greenhueblues-design
description: Use this skill to generate well-branded interfaces and assets for greenhueblues, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick start:
- Link `styles.css` (imports fonts + all tokens). Body text is Neue Haas Unica Pro on `--bg-page` (paper).
- Logo: `assets/logo/*.svg` (outlined) or the `Logo` component. The red full stop is mandatory.
- Icons: `assets/icons/*.svg` (Lucide, draw at stroke-width 1.5) or the `Icon` component.
- Components: `components/**` (`<Name>.jsx` + `.d.ts` + `.prompt.md`).
- Reference screens: `ui_kits/website/`.
