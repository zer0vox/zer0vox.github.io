const { Logo: HLogo, Button: HButton, IconButton: HIconButton } = window.GreenhuebluesDesignSystem_653a8b;

function NavLink({ active, onClick, children }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a href="#" onClick={(e) => { e.preventDefault(); onClick(); }} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ fontSize: 15, textDecoration: 'none', color: active || hover ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: active ? 500 : 400, transition: 'color var(--dur-fast) var(--ease-out)' }}>
      {children}<span style={{ color: 'var(--red-500)', opacity: active ? 1 : 0 }}>.</span>
    </a>
  );
}

function AnnouncementBar({ onOpen, onClose }) {
  return (
    <div style={{ background: 'var(--butter-400)', color: 'var(--marine-800)' }}>
      <div className="ghb-wrap" style={{ height: 36, display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, fontSize: 14 }}>
        <a href="#" onClick={(e) => { e.preventDefault(); onOpen(); }} style={{ color: 'inherit', textDecoration: 'none', display: 'flex', gap: 10, alignItems: 'center' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase' }}>New</span>
          <span>Tidal Index 2.0 is out — read the case study</span>
          <span aria-hidden="true">→</span>
        </a>
        <button type="button" aria-label="Dismiss" onClick={onClose} style={{ border: 0, background: 'transparent', color: 'inherit', cursor: 'pointer', fontSize: 18, lineHeight: 1, padding: 4 }}>×</button>
      </div>
    </div>
  );
}

function SiteHeader({ route, go }) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const on = () => setScrolled(window.scrollY > 8);
    window.addEventListener('scroll', on);
    return () => window.removeEventListener('scroll', on);
  }, []);
  const items = [['work', 'Work'], ['studio', 'Studio'], ['contact', 'Contact']];
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 'var(--z-header)', height: 'var(--header-height)',
      background: 'rgba(244,242,237,0.86)', backdropFilter: 'blur(var(--blur-header))', WebkitBackdropFilter: 'blur(var(--blur-header))',
      borderBottom: `1px solid ${scrolled ? 'var(--border-subtle)' : 'transparent'}`, transition: 'border-color var(--dur-base) var(--ease-out)',
    }}>
      <div className="ghb-wrap" style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 24 }}>
        <a href="#" aria-label="greenhueblues home" onClick={(e) => { e.preventDefault(); go({ name: 'home' }); }} style={{ textDecoration: 'none', display: 'flex' }}>
          <HLogo size={21} />
        </a>
        <nav style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
          <div className="hide-sm" style={{ display: 'flex', gap: 28 }}>
            {items.map(([id, label]) => (
              <NavLink key={id} active={route.name === id || (id === 'work' && route.name === 'project')} onClick={() => go({ name: id })}>{label}</NavLink>
            ))}
          </div>
          <HButton size="sm" iconRight="arrow-right" onClick={() => go({ name: 'contact' })}>Start a project</HButton>
        </nav>
      </div>
    </header>
  );
}

Object.assign(window, { SiteHeader, AnnouncementBar });
