const { Icon: LIcon } = window.GreenhuebluesDesignSystem_653a8b;

function IndexRow({ p, onOpen }) {
  const [hover, setHover] = React.useState(false);
  const cell = { fontSize: 15, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' };
  return (
    <a href="#" onClick={(e) => { e.preventDefault(); onOpen(p); }} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'grid', gridTemplateColumns: '56px minmax(0,2fr) minmax(0,1.6fr) 140px 56px 24px', alignItems: 'center', gap: 16,
        padding: '14px 0', borderBottom: '1px solid var(--border-subtle)', color: 'var(--text-primary)', textDecoration: 'none',
        background: hover ? 'var(--butter-300)' : 'transparent', boxShadow: hover ? '-8px 0 0 var(--butter-300), 8px 0 0 var(--butter-300)' : 'none', transition: 'background-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)',
      }}>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-tertiary)' }}>({p.idx})</span>
      <span style={{ ...cell, fontSize: 18, fontWeight: 500, letterSpacing: '-0.015em' }}>{p.title}</span>
      <span className="hide-sm" style={{ ...cell, color: 'var(--text-secondary)' }}>{p.client}</span>
      <span className="hide-sm" style={{ ...cell, color: 'var(--text-secondary)' }}>{p.discipline}</span>
      <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-tertiary)' }}>{p.year}</span>
      <span style={{ display: 'flex', transform: hover ? 'translateX(0)' : 'translateX(-6px)', opacity: hover ? 1 : 0, transition: 'all var(--dur-base) var(--ease-out)' }}>
        <LIcon name="arrow-right" size={18} />
      </span>
    </a>
  );
}

function IndexList({ projects, onOpen }) {
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '56px minmax(0,2fr) minmax(0,1.6fr) 140px 56px 24px', gap: 16, paddingBottom: 10, borderBottom: '1px solid var(--border-strong)', fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-tertiary)' }}>
        <span>No.</span><span>Project</span><span className="hide-sm">Client</span><span className="hide-sm">Discipline</span><span>Year</span><span></span>
      </div>
      {projects.map((p) => <IndexRow key={p.id} p={p} onOpen={onOpen} />)}
    </div>
  );
}

Object.assign(window, { IndexList });
