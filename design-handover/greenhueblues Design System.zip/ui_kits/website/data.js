window.GHB_PROJECTS = [
  { id: 'tidal-index', idx: '01', title: 'Tidal Index', client: 'Harbour Maritime Museum', discipline: 'Software', year: 2026, tone: 'marine', comp: 'word', word: 'Tidal', summary: 'Collection software and public catalogue for 40,000 maritime objects.' },
  { id: 'soft-machines', idx: '02', title: 'Soft Machines', client: 'Kunsthal Noord', discipline: 'Identity', year: 2025, tone: 'butter', comp: 'letter', word: 'S', summary: 'Identity and exhibition graphics for a survey of early computer art.' },
  { id: 'long-room', idx: '03', title: 'The Long Room', client: 'The Long Room Gallery', discipline: 'Identity', year: 2025, tone: 'paper', comp: 'word', word: 'Long', summary: 'A name, identity and website for a gallery in a former rope works.' },
  { id: 'field-notes', idx: '04', title: 'Field Notes Engine', client: 'Self-initiated', discipline: 'Software', year: 2024, tone: 'ink', comp: 'number', word: '024', summary: 'A generative print system that turns field recordings into posters.' },
  { id: 'red-hour', idx: '05', title: 'Red Hour', client: 'Lumen Festival', discipline: 'Installation', year: 2024, tone: 'red', comp: 'letter', word: 'R', summary: 'A light installation timed to the last hour before sunset.' },
  { id: 'paper-weather', idx: '06', title: 'Paper Weather', client: 'Atlas Editions', discipline: 'Print', year: 2023, tone: 'butter', comp: 'word', word: 'Weather', summary: 'A 240-page book of meteorological drawings, typeset in one weight.' },
  { id: 'small-things', idx: '07', title: 'Atlas of Small Things', client: 'City Archive', discipline: 'Software', year: 2023, tone: 'marine', comp: 'number', word: '07', summary: 'An archive website built around a single, very long index.' },
  { id: 'quiet-signal', idx: '08', title: 'Quiet Signal', client: 'Radio Kunst', discipline: 'Installation', year: 2022, tone: 'ink', comp: 'word', word: 'Quiet', summary: 'A sound installation and its printed programme.' },
];

window.GHB_SERVICES = [
  { n: '01', title: 'Identity', body: 'Names, marks, type systems and the guidelines that keep them consistent across print and screen.' },
  { n: '02', title: 'Websites', body: 'Editorial sites for galleries, archives and publishers, designed and built in-house.' },
  { n: '03', title: 'Software', body: 'Collection tools, generative systems and internal apps for creative teams.' },
];
