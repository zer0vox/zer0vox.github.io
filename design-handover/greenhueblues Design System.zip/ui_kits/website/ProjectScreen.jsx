const { Link: PLink, Badge: PBadge, Tag: PTag, Button: PButton } = window.GreenhuebluesDesignSystem_653a8b;

function MetaItem({ label, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 12, borderTop: '1px solid var(--border-strong)' }}>
      <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>{label}</span>
      <span style={{ fontSize: 15 }}>{children}</span>
    </div>
  );
}

function ProjectScreen({ route, go, openProject }) {
  const all = window.GHB_PROJECTS;
  const i = Math.max(0, all.findIndex((p) => p.id === route.id));
  const p = all[i];
  const next = all[(i + 1) % all.length];
  return (
    <main>
      <div className="ghb-wrap" style={{ paddingTop: 40 }}>
        <PLink href="#" tone="muted" underline="hover" onClick={(e) => { e.preventDefault(); go({ name: 'work' }); }}>← All work</PLink>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 'clamp(40px, 6vw, 88px)' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--text-tertiary)' }}>({p.idx})</span>
          {p.year >= 2026 && <PBadge tone="highlight">New</PBadge>}
        </div>
        <h1 className="ghb-h1" style={{ margin: '16px 0 0', maxWidth: '12em' }}>{p.title}<span style={{ color: 'var(--red-500)' }}>.</span></h1>
        <div className="g-12" style={{ marginTop: 48 }}>
          <p className="ghb-lede" style={{ gridColumn: 'span 7', margin: 0 }}>{p.summary}</p>
          <div style={{ gridColumn: '9 / span 4', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
            <MetaItem label="Client">{p.client}</MetaItem>
            <MetaItem label="Year">{p.year}</MetaItem>
            <MetaItem label="Discipline">{p.discipline}</MetaItem>
          </div>
        </div>
      </div>

      <div className="ghb-wrap" style={{ marginTop: 72 }}>
        <div style={{ position: 'relative', aspectRatio: '16 / 9' }}><ProjectArt project={p} fig="01" /></div>
      </div>

      <div className="ghb-wrap g-12" style={{ marginTop: 96 }}>
        <div style={{ gridColumn: 'span 3' }}><span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>The brief</span></div>
        <div style={{ gridColumn: '4 / span 6', display: 'flex', flexDirection: 'column', gap: 16 }}>
          <p className="ghb-body" style={{ margin: 0 }}>Placeholder case-study copy. Describe the client, the problem as they put it, and what changed once the work was in use. Keep each paragraph to one idea and let the images carry the rest.</p>
          <p className="ghb-body" style={{ margin: 0, color: 'var(--text-secondary)' }}>Credit collaborators by name. Link to anything that is live.</p>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
            {[p.discipline, 'Art direction', 'Web'].map((t) => <PTag key={t} size="sm">{t}</PTag>)}
          </div>
        </div>
      </div>

      <div className="ghb-wrap" style={{ marginTop: 96, display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 'var(--grid-gutter)' }}>
        <div style={{ position: 'relative', aspectRatio: '4 / 5' }}><ProjectArt project={{ ...p, comp: 'letter', word: p.title[0] }} fig="02" /></div>
        <div style={{ position: 'relative', aspectRatio: '4 / 5' }}><ProjectArt project={{ ...p, tone: 'paper', comp: 'number', word: p.idx }} fig="03" /></div>
      </div>

      <div className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, paddingTop: 20, borderTop: '1px solid var(--border-strong)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>Next project</span>
            <a href="#" className="ghb-h2" onClick={(e) => { e.preventDefault(); openProject(next); }} style={{ color: 'var(--text-primary)', textDecoration: 'none' }}>{next.title}</a>
          </div>
          <PButton variant="secondary" iconRight="arrow-right" onClick={() => openProject(next)}>Next</PButton>
        </div>
      </div>
    </main>
  );
}

Object.assign(window, { ProjectScreen });
