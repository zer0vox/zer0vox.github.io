const { Card: SCard, Button: SButton } = window.GreenhuebluesDesignSystem_653a8b;

function StudioScreen({ go }) {
  const clients = ['Harbour Maritime Museum', 'Kunsthal Noord', 'The Long Room Gallery', 'Lumen Festival', 'Atlas Editions', 'City Archive', 'Radio Kunst'];
  const principles = [
    ['Small teams', 'Every project is led by the people who design and build it. No hand-offs between departments.'],
    ['Tools as craft', 'We write software the way we set type: carefully, and for the people who will use it every day.'],
    ['Room for the work', 'Our clients show art. The design should frame it, then get out of the way.'],
  ];
  return (
    <main>
      <section className="ghb-wrap" style={{ paddingTop: 'clamp(56px, 8vw, 120px)' }}>
        <h1 className="ghb-h1" style={{ margin: 0 }}>Studio<span style={{ color: 'var(--red-500)' }}>.</span></h1>
        <div className="g-12" style={{ marginTop: 56 }}>
          <p className="ghb-lede" style={{ gridColumn: '1 / span 8', margin: 0, fontSize: 'clamp(24px, 2.6vw, 36px)' }}>
            We are designers and developers working on one floor. Half of our work is identity and editorial design; the other half is software that keeps creative organisations running.
          </p>
        </div>
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <SectionHead label="Approach" title="How we work" />
        <div className="g-3" style={{ gap: 'var(--grid-gutter)' }}>
          {principles.map(([t, b], i) => (
            <div key={t} style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-tertiary)' }}>({String(i + 1).padStart(2, '0')})</span>
              <h3 className="ghb-h3" style={{ margin: 0 }}>{t}</h3>
              <p className="ghb-body" style={{ margin: 0, color: 'var(--text-secondary)' }}>{b}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <SectionHead label="Services" title="What you can hire us for" />
        <div className="g-3" style={{ gap: 'var(--grid-gutter)' }}>
          {window.GHB_SERVICES.map((s) => <SCard key={s.n} variant="panel" eyebrow={s.n} title={s.title} description={s.body} style={{ minHeight: 200 }} />)}
        </div>
      </section>

      <section className="ghb-wrap g-12" style={{ marginTop: 'var(--section-gap)' }}>
        <div style={{ gridColumn: 'span 4' }}>
          <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>Selected clients</span>
        </div>
        <ul style={{ gridColumn: '5 / span 8', listStyle: 'none', margin: 0, padding: 0, columns: 2, columnGap: 'var(--grid-gutter)' }}>
          {clients.map((c) => <li key={c} style={{ fontSize: 22, letterSpacing: '-0.015em', lineHeight: 1.5, breakInside: 'avoid' }}>{c}</li>)}
        </ul>
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <div style={{ background: 'var(--butter-400)', color: 'var(--marine-800)', padding: 'clamp(32px, 5vw, 64px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
          <h2 className="ghb-h2" style={{ margin: 0, maxWidth: '14em' }}>We take on four or five new projects a year.</h2>
          <SButton size="lg" iconRight="arrow-right" onClick={() => go({ name: 'contact' })}>Start a project</SButton>
        </div>
      </section>
    </main>
  );
}

Object.assign(window, { StudioScreen });
