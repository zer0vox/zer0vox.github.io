// Typographic placeholder art for project media. Replace with real photography when available.
const ART_TONES = {
  marine: ['var(--marine-700)', 'var(--paper-100)', 'var(--butter-400)'],
  butter: ['var(--butter-400)', 'var(--marine-800)', 'var(--red-500)'],
  red: ['var(--red-500)', 'var(--ink-900)', 'var(--paper-100)'],
  paper: ['var(--paper-200)', 'var(--marine-700)', 'var(--red-500)'],
  ink: ['var(--ink-900)', 'var(--paper-100)', 'var(--butter-400)'],
};

function ProjectArt({ project, fig }) {
  const [bg, fg, ac] = ART_TONES[project.tone] || ART_TONES.paper;
  const big = { position: 'absolute', fontWeight: 500, letterSpacing: '-0.05em', lineHeight: 0.8, color: fg, whiteSpace: 'nowrap' };
  let body;
  if (project.comp === 'letter') {
    body = <span style={{ ...big, right: '-6cqw', bottom: '-14cqw', fontSize: '118cqw' }}>{project.word}</span>;
  } else if (project.comp === 'number') {
    body = <span style={{ ...big, left: '5cqw', top: '14cqw', fontSize: '42cqw', fontWeight: 300 }}>{project.word}</span>;
  } else {
    body = <span style={{ ...big, left: '5cqw', bottom: '6cqw', fontSize: '24cqw' }}>{project.word}<span style={{ color: ac }}>.</span></span>;
  }
  return (
    <div style={{ position: 'absolute', inset: 0, background: bg, containerType: 'inline-size', overflow: 'hidden' }}>
      {body}
      <span style={{ position: 'absolute', left: '5cqw', top: '5cqw', fontFamily: 'var(--font-mono)', fontSize: 11, color: fg, opacity: 0.75 }}>
        fig. {fig || project.idx}
      </span>
    </div>
  );
}

Object.assign(window, { ProjectArt });
