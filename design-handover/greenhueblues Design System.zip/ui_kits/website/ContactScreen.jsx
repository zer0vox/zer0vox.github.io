const { Input: CInput, Select: CSelect, RadioGroup: CRadioGroup, Checkbox: CCheckbox, Tag: CTag, Button: CButton, Toast: CToast, Dialog: CDialog, Link: CLink } = window.GreenhuebluesDesignSystem_653a8b;

function ContactScreen({ go }) {
  const [form, setForm] = React.useState({ name: '', email: '', org: '', budget: '', timeline: 'q', brief: '', letter: false });
  const [tags, setTags] = React.useState(['Identity']);
  const [errors, setErrors] = React.useState({});
  const [confirm, setConfirm] = React.useState(false);
  const [toast, setToast] = React.useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e && e.target ? e.target.value : e });
  const toggle = (t) => setTags(tags.includes(t) ? tags.filter((x) => x !== t) : [...tags, t]);

  const submit = (e) => {
    e.preventDefault();
    const er = {};
    if (!form.name) er.name = 'Tell us who you are.';
    if (!/^\S+@\S+\.\S+$/.test(form.email)) er.email = 'Enter an email we can reply to.';
    setErrors(er);
    if (!Object.keys(er).length) setConfirm(true);
  };
  const send = () => {
    setConfirm(false); setToast(true);
    setForm({ name: '', email: '', org: '', budget: '', timeline: 'q', brief: '', letter: false });
    setTimeout(() => setToast(false), 5000);
  };

  return (
    <main className="ghb-wrap" style={{ paddingTop: 'clamp(56px, 8vw, 120px)' }}>
      <div className="g-12">
        <div style={{ gridColumn: 'span 4', display: 'flex', flexDirection: 'column', gap: 32 }}>
          <h1 className="ghb-h1" style={{ margin: 0 }}>Start a project<span style={{ color: 'var(--red-500)' }}>.</span></h1>
          <p className="ghb-body" style={{ margin: 0, color: 'var(--text-secondary)', maxWidth: 340 }}>A few lines is enough. We read every brief and reply within two working days.</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: 15 }}>
            <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)', marginBottom: 4 }}>Or write to us</span>
            <CLink href="#">hello@greenhueblues.com</CLink>
          </div>
        </div>
        <form onSubmit={submit} noValidate style={{ gridColumn: '6 / span 7', display: 'flex', flexDirection: 'column', gap: 32 }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)', gap: 32 }}>
            <CInput variant="line" label="Name" value={form.name} onChange={set('name')} error={errors.name} placeholder="Your name" />
            <CInput variant="line" label="Email" type="email" value={form.email} onChange={set('email')} error={errors.email} placeholder="you@organisation.org" />
            <CInput variant="line" label="Organisation" value={form.org} onChange={set('org')} placeholder="Optional" />
            <CSelect variant="line" label="Budget" value={form.budget} onChange={set('budget')} placeholder="Choose a range" options={['Under 25k', '25–75k', '75k and up', 'Not sure yet']} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>What do you need?</span>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {['Identity', 'Website', 'Software', 'Installation', 'Print', 'Not sure'].map((t) => <CTag key={t} selected={tags.includes(t)} onClick={() => toggle(t)}>{t}</CTag>)}
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>When?</span>
            <CRadioGroup name="timeline" direction="row" value={form.timeline} onChange={set('timeline')} options={[{ value: 'asap', label: 'As soon as possible' }, { value: 'q', label: 'Next quarter' }, { value: 'later', label: 'Later this year' }]} />
          </div>
          <CInput variant="line" label="Brief" multiline rows={4} value={form.brief} onChange={set('brief')} placeholder="What are you making, and who is it for?" />
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
            <CCheckbox checked={form.letter} onChange={(v) => setForm({ ...form, letter: v })} label="Send me the studio letter" description="Four times a year." />
            <CButton type="submit" size="lg" iconRight="arrow-right">Send brief</CButton>
          </div>
        </form>
      </div>

      <CDialog open={confirm} onClose={() => setConfirm(false)} eyebrow="Enquiry" title="Send your brief?"
        actions={<><CButton variant="ghost" onClick={() => setConfirm(false)}>Edit</CButton><CButton onClick={send}>Send</CButton></>}>
        We'll reply to {form.email || 'you'} within two working days{tags.length ? ` about ${tags.join(', ').toLowerCase()}` : ''}.
      </CDialog>
      {toast && (
        <div style={{ position: 'fixed', left: 24, bottom: 24, zIndex: 'var(--z-toast)' }}>
          <CToast tone="success" title="Brief sent" message="Thanks. We'll be in touch soon." onClose={() => setToast(false)} />
        </div>
      )}
    </main>
  );
}

Object.assign(window, { ContactScreen });
