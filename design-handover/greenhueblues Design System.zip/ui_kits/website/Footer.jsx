const { Logo: FLogo, Link: FLink, Input: FInput, IconButton: FIconButton } = window.GreenhuebluesDesignSystem_653a8b;

function SiteFooter({ go }) {
  const [email, setEmail] = React.useState('');
  const [joined, setJoined] = React.useState(false);
  const col = { display: 'flex', flexDirection: 'column', gap: 8, fontSize: 15 };
  const label = { fontFamily: 'var(--font-mono)', fontSize: 11, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-on-inverse-muted)', marginBottom: 6 };
  return (
    <footer style={{ background: 'var(--surface-inverse)', color: 'var(--text-on-inverse)', marginTop: 'var(--section-gap)' }}>
      <div className="ghb-wrap" style={{ paddingTop: 96, paddingBottom: 32 }}>
        <div style={label}>Have a project in mind?</div>
        <a href="#" onClick={(e) => { e.preventDefault(); go({ name: 'contact' }); }}
          style={{ display: 'inline-block', color: 'var(--paper-100)', textDecoration: 'none', fontSize: 'clamp(40px, 7vw, 104px)', fontWeight: 500, letterSpacing: '-0.045em', lineHeight: 0.95 }}
          onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--butter-400)')} onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--paper-100)')}>
          hello@greenhueblues.com
        </a>
        <div className="g-12" style={{ marginTop: 96, paddingTop: 24, borderTop: '1px solid var(--border-inverse)' }}>
          <div style={{ ...col, gridColumn: 'span 3' }}>
            <div style={label}>Studio</div>
            <span>Placeholder Street 12</span><span>City, Country</span>
          </div>
          <div style={{ ...col, gridColumn: 'span 3' }}>
            <div style={label}>Elsewhere</div>
            <FLink href="#" tone="inverse" arrow="up-right" underline="hover">Instagram</FLink>
            <FLink href="#" tone="inverse" arrow="up-right" underline="hover">LinkedIn</FLink>
            <FLink href="#" tone="inverse" arrow="up-right" underline="hover">GitHub</FLink>
          </div>
          <div style={{ ...col, gridColumn: '8 / span 5' }}>
            <div style={label}>Studio letter</div>
            {joined ? (
              <span style={{ fontSize: 18, fontWeight: 300 }}>Thanks. The next one goes out in spring<span style={{ color: 'var(--red-500)' }}>.</span></span>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); if (email) setJoined(true); }} style={{ display: 'flex', alignItems: 'flex-end', gap: 12 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email address" aria-label="Email address"
                    style={{ width: '100%', height: 44, background: 'transparent', border: 0, borderBottom: '1px solid var(--border-inverse)', color: 'var(--paper-100)', fontFamily: 'var(--font-sans)', fontSize: 18, outline: 'none' }} />
                </div>
                <FIconButton icon="arrow-right" label="Subscribe" variant="inverse" type="submit" />
              </form>
            )}
            <span style={{ fontSize: 13, color: 'var(--text-on-inverse-muted)' }}>Four times a year. New work, tools and reading.</span>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 64, gap: 16 }}>
          <FLogo tone="inverse" size={18} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-on-inverse-muted)' }}>© 2026 greenhueblues</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { SiteFooter });
