# Website UI kit — greenhueblues

Proposed studio website for the greenhueblues revamp. There was no existing site to recreate, so these screens are a **first design proposal** built entirely from the system's tokens and components.

## Screens (click-through in `index.html`)
- **Home** — hero 3a from `Hero Explorations.html` (marine ink print of the gallery sculpture, butter string-art aureole, vertical red multiply band), featured work (asymmetric 7/5 + 3-up), project index, services panels.
- **Work** — filter tabs with counts, Grid/List segment toggle.
- **Project** — case-study layout: index + title, lede, meta, 16:9 hero, brief, 2-up media, next project.
- **Studio** — approach, services, clients, butter call-to-action block.
- **Contact** — line-variant form, discipline tags, timeline radios, validation, confirm Dialog, success Toast.

The route persists in `localStorage` (`ghb-website-route`).

## Files
- `data.js` — placeholder projects + services (all names/clients are fictional).
- `Art.jsx` — typographic placeholder media (tone field + oversized word/letter/number + `fig.` caption). Swap for photography.
- `Header.jsx` — announcement bar (butter), sticky blurred header, nav with red full stop on the active item.
- `Footer.jsx` — marine footer: display email, links, studio-letter signup.
- `IndexList.jsx` — tabular project index; rows highlight in butter on hover.
- `HomeScreen.jsx`, `WorkScreen.jsx`, `ProjectScreen.jsx`, `StudioScreen.jsx`, `ContactScreen.jsx`.

Components come from the compiled bundle (`window.GreenhuebluesDesignSystem_653a8b`): Logo, Button, IconButton, Link, Icon, Card, Badge, Tag, Tabs, Input, Select, RadioGroup, Checkbox, Dialog, Toast.
