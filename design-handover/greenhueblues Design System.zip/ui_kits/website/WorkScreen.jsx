const { Tabs: WTabs, Card: WCard } = window.GreenhuebluesDesignSystem_653a8b;

function WorkScreen({ route, go, openProject }) {
  const all = window.GHB_PROJECTS;
  const [filter, setFilter] = React.useState('all');
  const [view, setView] = React.useState(route.view === 'list' ? 'List' : 'Grid');
  const disciplines = ['Identity', 'Software', 'Installation', 'Print'];
  const items = [{ id: 'all', label: 'All', count: all.length }, ...disciplines.map((d) => ({ id: d, label: d, count: all.filter((p) => p.discipline === d).length }))];
  const list = filter === 'all' ? all : all.filter((p) => p.discipline === filter);
  return (
    <main className="ghb-wrap" style={{ paddingTop: 'clamp(56px, 8vw, 120px)' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, flexWrap: 'wrap' }}>
        <h1 className="ghb-h1" style={{ margin: 0 }}>Work<span style={{ color: 'var(--red-500)' }}>.</span></h1>
        <p className="ghb-small" style={{ margin: 0, maxWidth: 360, color: 'var(--text-secondary)' }}>Selected projects from 2022 to now. Most started with a short conversation.</p>
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, marginTop: 48, marginBottom: 40 }}>
        <WTabs items={items} value={filter} onChange={setFilter} style={{ flex: 1 }} />
        <WTabs variant="segment" items={['Grid', 'List']} value={view} onChange={setView} style={{ marginBottom: 8 }} />
      </div>
      {view === 'Grid' ? (
        <div className="g-3">
          {list.map((p, i) => (
            <WCard key={p.id} href="#" onClick={(e) => { e && e.preventDefault && e.preventDefault(); openProject(p); }}
              eyebrow={`(${p.idx})`} title={p.title} meta={`${p.year} — ${p.discipline}`} aspect={i % 3 === 1 ? '4 / 5' : '4 / 3'}
              media={<ProjectArt project={p} />} />
          ))}
        </div>
      ) : (
        <IndexList projects={list} onOpen={openProject} />
      )}
    </main>
  );
}

Object.assign(window, { WorkScreen });
