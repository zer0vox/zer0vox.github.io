const { Button: HmButton, Card: HmCard, Link: HmLink } = window.GreenhuebluesDesignSystem_653a8b;

function SectionHead({ label, title, action }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 24, paddingBottom: 20, marginBottom: 32, borderBottom: '1px solid var(--border-strong)' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <span className="ghb-eyebrow" style={{ color: 'var(--text-tertiary)' }}>{label}</span>
        <h2 className="ghb-h2" style={{ margin: 0 }}>{title}</h2>
      </div>
      {action}
    </div>
  );
}

function HomeScreen({ go, openProject }) {
  const P = window.GHB_PROJECTS;
  return (
    <main>
      <section className="hero">
        <div className="hero-art" aria-hidden="true">
          <img className="ha-shape" src="../../assets/imagery/string-shape-butter.png" alt="" />
          <img className="ha-print" src="../../assets/imagery/hanu-bhairava-print-ink.png" alt="" />
          <div className="ha-rib"></div>
        </div>
        <div className="hero-text">
          <div className="ghb-wrap">
            <div style={{ maxWidth: 700, display: 'flex', flexDirection: 'column' }}>
              <h1 style={{ margin: 0, fontSize: 'clamp(48px, 7.2vw, 104px)', fontWeight: 500, letterSpacing: '-0.05em', lineHeight: 0.92 }}>
                Design and software for the art world<span style={{ color: 'var(--red-500)' }}>.</span>
              </h1>
              <p style={{ margin: '36px 0 0', maxWidth: 500, fontSize: 20, fontWeight: 300, lineHeight: 1.3, color: 'var(--text-secondary)' }}>
                greenhueblues is a small studio making identities, websites and tools for galleries, archives and the people who run them.
              </p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginTop: 36, flexWrap: 'wrap' }}>
                <HmButton size="lg" iconRight="arrow-right" onClick={() => go({ name: 'contact' })}>Start a project</HmButton>
                <HmLink href="#" tone="brand" arrow="right" size={16} onClick={(e) => { e.preventDefault(); go({ name: 'work' }); }}>View work</HmLink>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'clamp(64px, 8vw, 120px)' }}>
        <div className="g-feature" style={{ alignItems: 'start' }}>
          <HmCard href="#" onClick={(e) => { e && e.preventDefault && e.preventDefault(); openProject(P[0]); }} eyebrow={`(${P[0].idx})`} title={P[0].title} meta={`${P[0].year} — ${P[0].discipline}`} description={P[0].summary} aspect="4 / 3" media={<ProjectArt project={P[0]} />} />
          <div style={{ paddingTop: 'clamp(0px, 12vw, 180px)' }}>
            <HmCard href="#" onClick={(e) => { e && e.preventDefault && e.preventDefault(); openProject(P[1]); }} eyebrow={`(${P[1].idx})`} title={P[1].title} meta={`${P[1].year} — ${P[1].discipline}`} description={P[1].summary} aspect="4 / 5" media={<ProjectArt project={P[1]} />} />
          </div>
        </div>
        <div className="g-3" style={{ marginTop: 72 }}>
          {P.slice(2, 5).map((p) => (
            <HmCard key={p.id} href="#" onClick={(e) => { e && e.preventDefault && e.preventDefault(); openProject(p); }} eyebrow={`(${p.idx})`} title={p.title} meta={`${p.year}`} aspect="1 / 1" media={<ProjectArt project={p} />} />
          ))}
        </div>
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <SectionHead label="Index" title="Everything, in order" action={<HmLink href="#" arrow="right" onClick={(e) => { e.preventDefault(); go({ name: 'work', view: 'list' }); }}>All work</HmLink>} />
        <IndexList projects={P.slice(0, 6)} onOpen={openProject} />
      </section>

      <section className="ghb-wrap" style={{ marginTop: 'var(--section-gap)' }}>
        <SectionHead label="What we do" title="Three disciplines, one team" action={<HmLink href="#" arrow="right" onClick={(e) => { e.preventDefault(); go({ name: 'studio' }); }}>The studio</HmLink>} />
        <div className="g-3" style={{ gap: 'var(--grid-gutter)' }}>
          {window.GHB_SERVICES.map((s) => (
            <HmCard key={s.n} variant="panel" eyebrow={s.n} title={s.title} description={s.body} style={{ minHeight: 220 }} />
          ))}
        </div>
      </section>
    </main>
  );
}

Object.assign(window, { HomeScreen, SectionHead });
