/** Pill tag for disciplines, filters and keywords. Becomes a toggle button when onClick is set. */
export interface TagProps {
  children?: React.ReactNode;
  /** Filled ink when selected */
  selected?: boolean;
  onClick?: () => void;
  /** Shows a trailing × */
  onRemove?: () => void;
  size?: 'sm' | 'md';
  tone?: 'default' | 'inverse';
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Tag(props: TagProps): JSX.Element;
