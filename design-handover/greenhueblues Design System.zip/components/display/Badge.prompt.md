Use Badge for short status/meta labels (New, In progress, Live).

```jsx
<Badge tone="highlight">New</Badge>
<Badge tone="success" dot>Live</Badge>
```

- Mono uppercase 11px, 2px radius. Variants soft (default), solid, outline.
