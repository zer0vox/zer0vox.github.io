Use Card `project` for work grids (media + caption) and `panel` for bordered text blocks such as services.

```jsx
<Card href="/work/tidal" eyebrow="(01)" title="Tidal Index" meta="2026 — Software" mediaTone="marine" aspect="4 / 5" media={<img src="…" style={{width:'100%',height:'100%',objectFit:'cover'}} />} />
<Card variant="panel" eyebrow="02 — Software" title="Tools for creative teams" description="…" />
```

- Media is square-cornered, flat, no shadow; hover zooms media 2.5% and underlines the title.
- Without real imagery use `mediaTone` fields with type, never stock-photo filler.
