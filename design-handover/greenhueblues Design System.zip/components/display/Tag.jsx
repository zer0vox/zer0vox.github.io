import React from 'react';
import { Icon } from '../brand/Icon.jsx';

export function Tag({ children, selected = false, onClick, onRemove, size = 'md', tone = 'default', disabled = false, style }) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick && !disabled;
  const h = size === 'sm' ? 26 : 32;
  const inverse = tone === 'inverse';
  let bg = 'transparent', fg = inverse ? 'var(--paper-100)' : 'var(--text-primary)', bd = inverse ? 'var(--border-inverse)' : 'var(--border-default)';
  if (selected) { bg = inverse ? 'var(--paper-100)' : 'var(--ink-900)'; fg = inverse ? 'var(--marine-800)' : 'var(--paper-100)'; bd = bg; }
  else if (hover && interactive) { bd = inverse ? 'var(--paper-100)' : 'var(--border-strong)'; }
  const Tag_ = onClick ? 'button' : 'span';
  return (
    <Tag_
      type={onClick ? 'button' : undefined}
      aria-pressed={onClick ? selected : undefined}
      disabled={onClick ? disabled : undefined}
      onClick={interactive ? onClick : undefined}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, height: h, padding: onRemove ? '0 8px 0 12px' : '0 12px',
        fontFamily: 'var(--font-sans)', fontSize: size === 'sm' ? 'var(--text-xs)' : 'var(--text-sm)', fontWeight: 400, lineHeight: 1, whiteSpace: 'nowrap',
        borderRadius: 'var(--radius-pill)', border: `1px solid ${bd}`, background: bg, color: fg,
        cursor: interactive ? 'pointer' : 'default', opacity: disabled ? 0.45 : 1,
        transition: 'background-color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
        ...style,
      }}
    >
      {children}
      {onRemove && (
        <span role="button" aria-label="Remove" onClick={(e) => { e.stopPropagation(); onRemove(); }} style={{ display: 'inline-flex', cursor: 'pointer', opacity: 0.7 }}>
          <Icon name="x" size={14} />
        </span>
      )}
    </Tag_>
  );
}
