Use Tag for disciplines, keywords and filter chips.

```jsx
<Tag>Identity</Tag>
<Tag selected onClick={toggle}>Software</Tag>
<Tag onRemove={remove}>Motion</Tag>
```

- Pill, hairline border. Selected = ink fill. `tone="inverse"` on marine.
