import React from 'react';

const MEDIA_TONES = {
  marine: { background: 'var(--marine-700)', color: 'var(--paper-100)' },
  butter: { background: 'var(--butter-400)', color: 'var(--marine-800)' },
  red: { background: 'var(--red-500)', color: 'var(--ink-900)' },
  paper: { background: 'var(--paper-200)', color: 'var(--ink-700)' },
  ink: { background: 'var(--ink-900)', color: 'var(--paper-100)' },
};

export function Card({
  variant = 'project', media, mediaTone = 'paper', aspect = '4 / 3', eyebrow, title, meta, description,
  href, footer, children, style, onClick,
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!(href || onClick);
  const Tag = href ? 'a' : 'div';
  const common = {
    href, onClick,
    onMouseEnter: () => setHover(true), onMouseLeave: () => setHover(false),
  };

  if (variant === 'panel') {
    return (
      <Tag {...common} style={{
        display: 'flex', flexDirection: 'column', gap: 12, padding: 'var(--space-6)', textDecoration: 'none', color: 'inherit',
        background: 'var(--surface-card)', border: `1px solid ${hover && interactive ? 'var(--border-strong)' : 'var(--border-subtle)'}`,
        borderRadius: 'var(--radius-0)', cursor: interactive ? 'pointer' : undefined,
        transition: 'border-color var(--dur-fast) var(--ease-out)', ...style,
      }}>
        {eyebrow && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase', color: 'var(--text-tertiary)' }}>{eyebrow}</span>}
        {title && <span style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-medium)', letterSpacing: 'var(--tracking-tight)', lineHeight: 1.2, color: 'var(--text-primary)' }}>{title}</span>}
        {description && <span style={{ fontSize: 'var(--text-sm)', lineHeight: 1.55, color: 'var(--text-secondary)' }}>{description}</span>}
        {children}
        {footer && <div style={{ marginTop: 'auto', paddingTop: 12 }}>{footer}</div>}
      </Tag>
    );
  }

  const tone = MEDIA_TONES[mediaTone] || MEDIA_TONES.paper;
  return (
    <Tag {...common} style={{ display: 'flex', flexDirection: 'column', gap: 14, textDecoration: 'none', color: 'inherit', cursor: interactive ? 'pointer' : undefined, minWidth: 0, ...style }}>
      <div style={{ position: 'relative', aspectRatio: aspect, overflow: 'hidden', borderRadius: 'var(--radius-0)', ...tone }}>
        <div style={{ position: 'absolute', inset: 0, transform: hover && interactive ? 'scale(1.025)' : 'none', transition: 'transform var(--dur-reveal) var(--ease-out)' }}>
          {media}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 16 }}>
          <span style={{
            fontSize: 'var(--text-md)', fontWeight: 'var(--weight-medium)', letterSpacing: 'var(--tracking-tight)', lineHeight: 1.25, color: 'var(--text-primary)',
            textDecorationLine: hover && interactive ? 'underline' : 'none', textDecorationThickness: '1px', textUnderlineOffset: '0.18em',
          }}>
            {eyebrow && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', fontWeight: 400, color: 'var(--text-tertiary)', marginRight: 10, letterSpacing: 0 }}>{eyebrow}</span>}
            {title}
          </span>
          {meta && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', whiteSpace: 'nowrap' }}>{meta}</span>}
        </div>
        {description && <span style={{ fontSize: 'var(--text-sm)', lineHeight: 1.5, color: 'var(--text-secondary)' }}>{description}</span>}
        {children}
      </div>
    </Tag>
  );
}
