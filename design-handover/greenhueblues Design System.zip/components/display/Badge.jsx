import React from 'react';

const SOFT = {
  neutral: ['var(--paper-200)', 'var(--ink-600)'],
  brand: ['var(--marine-50)', 'var(--marine-700)'],
  accent: ['var(--red-50)', 'var(--red-700)'],
  highlight: ['var(--butter-200)', 'var(--marine-800)'],
  success: ['var(--status-success-bg)', 'var(--green-700)'],
  warning: ['var(--status-warning-bg)', 'var(--status-warning)'],
  danger: ['var(--status-danger-bg)', 'var(--status-danger)'],
};
const SOLID = {
  neutral: ['var(--ink-900)', 'var(--paper-100)'],
  brand: ['var(--marine-700)', 'var(--paper-100)'],
  accent: ['var(--red-500)', 'var(--ink-900)'],
  highlight: ['var(--butter-400)', 'var(--marine-800)'],
  success: ['var(--green-600)', 'var(--paper-0)'],
  warning: ['var(--butter-500)', 'var(--ink-900)'],
  danger: ['var(--red-700)', 'var(--paper-0)'],
};
const DOT = { neutral: 'var(--ink-500)', brand: 'var(--marine-700)', accent: 'var(--red-500)', highlight: 'var(--butter-600)', success: 'var(--green-600)', warning: 'var(--butter-600)', danger: 'var(--red-600)' };

export function Badge({ tone = 'neutral', variant = 'soft', dot = false, children, style }) {
  const [bg, fg] = (variant === 'solid' ? SOLID : SOFT)[tone] || SOFT.neutral;
  const outline = variant === 'outline';
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6, height: 20, padding: '0 7px',
      fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 400, letterSpacing: '0.06em', textTransform: 'uppercase', lineHeight: 1,
      borderRadius: 'var(--radius-xs)', whiteSpace: 'nowrap',
      background: outline ? 'transparent' : bg, color: outline ? 'var(--text-secondary)' : fg,
      border: outline ? '1px solid var(--border-default)' : '1px solid transparent', ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, background: variant === 'solid' ? 'currentColor' : DOT[tone], flexShrink: 0 }} />}
      {children}
    </span>
  );
}
