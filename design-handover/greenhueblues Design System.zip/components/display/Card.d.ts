/**
 * Project tile (media + caption) or bordered panel.
 */
export interface CardProps {
  /** project = square-cornered media with caption below (work grids) · panel = hairline-bordered text block (services, notes) */
  variant?: 'project' | 'panel';
  /** Image/video/any node, fills the media frame (position absolute, inset 0) */
  media?: React.ReactNode;
  /** Flat fill behind media / placeholder when no media */
  mediaTone?: 'marine' | 'butter' | 'red' | 'paper' | 'ink';
  /** CSS aspect-ratio for media. Default "4 / 3" */
  aspect?: string;
  /** project: mono index before title, e.g. "(04)" · panel: mono eyebrow above title */
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  /** Mono right-aligned meta, e.g. "2026 — Identity" */
  meta?: React.ReactNode;
  description?: React.ReactNode;
  href?: string;
  onClick?: () => void;
  /** panel only — pinned to bottom */
  footer?: React.ReactNode;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
