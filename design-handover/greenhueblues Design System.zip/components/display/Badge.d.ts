/** Small mono uppercase status label. */
export interface BadgeProps {
  tone?: 'neutral' | 'brand' | 'accent' | 'highlight' | 'success' | 'warning' | 'danger';
  variant?: 'soft' | 'solid' | 'outline';
  /** Leading square dot (echoes the logo full stop) */
  dot?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
