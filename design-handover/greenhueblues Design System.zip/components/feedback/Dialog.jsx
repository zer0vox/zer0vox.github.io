import React from 'react';
import { IconButton } from '../actions/IconButton.jsx';

export function Dialog({ open = false, onClose, eyebrow, title, children, actions, width = 480, contained = false }) {
  const [shown, setShown] = React.useState(open);
  React.useEffect(() => {
    if (open) { const r = requestAnimationFrame(() => setShown(true)); return () => cancelAnimationFrame(r); }
    setShown(false);
  }, [open]);
  React.useEffect(() => {
    if (!open || !onClose) return;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      onClick={onClose}
      style={{
        position: contained ? 'absolute' : 'fixed', inset: 0, zIndex: 'var(--z-overlay)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24,
        background: 'var(--scrim)', backdropFilter: 'blur(3px)', WebkitBackdropFilter: 'blur(3px)',
        opacity: shown ? 1 : 0, transition: 'opacity var(--dur-base) var(--ease-out)',
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === 'string' ? title : undefined}
        onClick={(e) => e.stopPropagation()}
        style={{
          width: '100%', maxWidth: width, background: 'var(--surface-raised)', borderRadius: 'var(--radius-0)', boxShadow: 'var(--shadow-overlay)',
          display: 'flex', flexDirection: 'column',
          transform: shown ? 'none' : 'translateY(8px)', transition: 'transform var(--dur-slow) var(--ease-out)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, padding: '20px 20px 0 24px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingTop: 4 }}>
            {eyebrow && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase', color: 'var(--text-tertiary)' }}>{eyebrow}</span>}
            {title && <span style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-medium)', letterSpacing: 'var(--tracking-tight)', lineHeight: 1.2 }}>{title}</span>}
          </div>
          {onClose && <IconButton icon="x" label="Close" variant="ghost" size="sm" onClick={onClose} />}
        </div>
        <div style={{ padding: '12px 24px 24px', fontSize: 'var(--text-sm)', lineHeight: 1.55, color: 'var(--text-secondary)' }}>{children}</div>
        {actions && (
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, padding: '16px 24px', borderTop: '1px solid var(--border-subtle)' }}>{actions}</div>
        )}
      </div>
    </div>
  );
}
