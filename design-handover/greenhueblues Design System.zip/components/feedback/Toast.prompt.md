Use Toast for brief, non-blocking confirmation after an action.

```jsx
<Toast tone="success" title="Message sent" message="We'll be in touch." onClose={dismiss} />
```

- Ink bar, square tone dot, butter action link. Place bottom-left with 24px inset; auto-dismiss after ~5s.
