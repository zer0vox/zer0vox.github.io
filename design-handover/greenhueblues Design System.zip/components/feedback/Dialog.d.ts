/** Modal dialog: square white panel over a marine scrim. Esc and scrim click close. */
export interface DialogProps {
  open?: boolean;
  onClose?: () => void;
  eyebrow?: React.ReactNode;
  title?: React.ReactNode;
  children?: React.ReactNode;
  /** Right-aligned footer, typically <Button variant="ghost"> + <Button> */
  actions?: React.ReactNode;
  /** max width px. Default 480 */
  width?: number;
  /** Position absolute inside the nearest positioned parent (for demos/embeds) instead of fixed */
  contained?: boolean;
}
export declare function Dialog(props: DialogProps): JSX.Element | null;
