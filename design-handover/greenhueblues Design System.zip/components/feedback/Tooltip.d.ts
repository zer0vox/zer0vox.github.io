/** Small ink label on hover/focus of its child. */
export interface TooltipProps {
  label: React.ReactNode;
  placement?: 'top' | 'bottom' | 'left' | 'right';
  /** Force open (demos) */
  open?: boolean;
  /** ms before showing. Default 120 */
  delay?: number;
  children: React.ReactNode;
}
export declare function Tooltip(props: TooltipProps): JSX.Element;
