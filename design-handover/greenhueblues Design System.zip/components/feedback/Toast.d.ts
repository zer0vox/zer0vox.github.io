/** Ink notification bar with a square tone dot. Position it yourself (bottom-left, 24px). */
export interface ToastProps {
  tone?: 'neutral' | 'success' | 'warning' | 'danger' | 'accent';
  title?: React.ReactNode;
  message?: React.ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  onClose?: () => void;
  style?: React.CSSProperties;
}
export declare function Toast(props: ToastProps): JSX.Element;
