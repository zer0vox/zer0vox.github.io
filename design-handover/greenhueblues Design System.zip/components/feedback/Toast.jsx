import React from 'react';
import { Icon } from '../brand/Icon.jsx';

const DOTS = { neutral: 'var(--paper-100)', success: '#5CC497', warning: 'var(--butter-400)', danger: 'var(--red-500)', accent: 'var(--red-500)' };

export function Toast({ tone = 'neutral', title, message, actionLabel, onAction, onClose, style }) {
  return (
    <div role="status" style={{
      display: 'flex', alignItems: 'flex-start', gap: 12, width: '100%', maxWidth: 380, padding: '14px 14px 14px 16px',
      background: 'var(--ink-900)', color: 'var(--paper-100)', borderRadius: 'var(--radius-xs)', boxShadow: 'var(--shadow-overlay)', ...style,
    }}>
      <span style={{ width: 8, height: 8, marginTop: 6, flexShrink: 0, background: DOTS[tone] || DOTS.neutral }} />
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
        {title && <span style={{ fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-medium)', lineHeight: 1.4 }}>{title}</span>}
        {message && <span style={{ fontSize: 'var(--text-sm)', lineHeight: 1.45, color: 'var(--ink-300)' }}>{message}</span>}
        {actionLabel && (
          <button type="button" onClick={onAction} style={{
            alignSelf: 'flex-start', marginTop: 6, padding: 0, border: 0, background: 'transparent', cursor: 'pointer',
            fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-medium)', color: 'var(--butter-400)',
            textDecoration: 'underline', textUnderlineOffset: '0.2em', textDecorationThickness: '1px',
          }}>{actionLabel}</button>
        )}
      </div>
      {onClose && (
        <button type="button" aria-label="Dismiss" onClick={onClose} style={{ display: 'inline-flex', padding: 2, border: 0, background: 'transparent', color: 'var(--ink-300)', cursor: 'pointer' }}>
          <Icon name="x" size={16} />
        </button>
      )}
    </div>
  );
}
