Use Dialog for confirmations and short focused tasks that block the page.

```jsx
<Dialog open={open} onClose={close} eyebrow="Enquiry" title="Send your brief?" actions={<><Button variant="ghost" onClick={close}>Cancel</Button><Button>Send</Button></>}>
  We'll reply within two working days.
</Dialog>
```

- Square white panel, marine scrim with 3px blur. `contained` for in-card demos.
