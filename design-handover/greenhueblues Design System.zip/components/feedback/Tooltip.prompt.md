Use Tooltip to name icon-only controls or reveal a short definition.

```jsx
<Tooltip label="Copy link"><IconButton icon="link" label="Copy link" variant="ghost" /></Tooltip>
```
