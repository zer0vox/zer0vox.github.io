import React from 'react';

export function Tooltip({ label, placement = 'top', open, delay = 120, children }) {
  const [hover, setHover] = React.useState(false);
  const timer = React.useRef(null);
  const show = open ?? hover;
  const enter = () => { clearTimeout(timer.current); timer.current = setTimeout(() => setHover(true), delay); };
  const leave = () => { clearTimeout(timer.current); setHover(false); };
  React.useEffect(() => () => clearTimeout(timer.current), []);
  const pos = {
    top: { bottom: 'calc(100% + 8px)', left: '50%', transform: `translateX(-50%) translateY(${show ? 0 : 4}px)` },
    bottom: { top: 'calc(100% + 8px)', left: '50%', transform: `translateX(-50%) translateY(${show ? 0 : -4}px)` },
    left: { right: 'calc(100% + 8px)', top: '50%', transform: `translateY(-50%) translateX(${show ? 0 : 4}px)` },
    right: { left: 'calc(100% + 8px)', top: '50%', transform: `translateY(-50%) translateX(${show ? 0 : -4}px)` },
  }[placement];
  return (
    <span style={{ position: 'relative', display: 'inline-flex' }} onMouseEnter={enter} onMouseLeave={leave} onFocus={enter} onBlur={leave}>
      {children}
      <span role="tooltip" style={{
        position: 'absolute', ...pos, zIndex: 'var(--z-tooltip)', pointerEvents: 'none', whiteSpace: 'nowrap',
        padding: '6px 8px', borderRadius: 'var(--radius-xs)', background: 'var(--ink-900)', color: 'var(--paper-100)',
        fontFamily: 'var(--font-sans)', fontSize: 'var(--text-xs)', lineHeight: 1.2, fontWeight: 400,
        opacity: show ? 1 : 0, transition: 'opacity var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)',
      }}>{label}</span>
    </span>
  );
}
