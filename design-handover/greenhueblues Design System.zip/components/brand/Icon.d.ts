/** Lucide icon (copied subset, 1.5 stroke). See assets/icons/ for available names. */
export interface IconProps {
  /** Lucide icon name, e.g. "arrow-right", "arrow-up-right", "plus", "x", "search", "mail". */
  name: string;
  /** px or CSS length. Default 20. */
  size?: number | string;
  /** Default 1.5 — the house weight. Use 1.75–2 below 16px. */
  strokeWidth?: number;
  color?: string;
  /** When set, the icon is announced; otherwise aria-hidden. */
  title?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element | null;
export declare const iconNames: string[];
