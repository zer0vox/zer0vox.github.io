Use Logo wherever the greenhueblues mark appears — headers, footers, covers, favicons — instead of typing the name.

```jsx
<Logo size={22} />                         // header
<Logo variant="stacked" tone="inverse" size={96} />  // cover on marine
<Logo variant="monogram" size={28} />       // avatar / tight spaces
```

- Variants: `wordmark` (default), `stacked` (green / hue / blues.), `monogram` (ghb.).
- Tones: `marine` on paper, `inverse` on marine or ink, `ink` for mono print, `mono` = currentColor (red dot dropped).
- The red full stop is the brand's one fixed accent; never recolour it, never drop it except in `mono`.
- Outlined SVGs live in assets/logo/ for contexts without the webfont.
