Use Icon for any UI glyph; it renders a Lucide outline icon at the house 1.5 stroke.

```jsx
<Icon name="arrow-up-right" size={18} />
<Icon name="search" size={16} color="var(--text-tertiary)" />
```

- 65 names bundled (see `iconNames` / assets/icons/). Arrows (`arrow-right`, `arrow-up-right`) carry most of the visual weight in this brand.
- Inherit colour from text (`currentColor`). Bump `strokeWidth` to 1.75–2 below 16px.
