import React from 'react';

const TONES = {
  marine: ['var(--marine-700)', 'var(--red-500)'],
  ink: ['var(--ink-900)', 'var(--red-500)'],
  inverse: ['var(--paper-100)', 'var(--red-500)'],
  mono: ['currentColor', 'currentColor'],
};

export function Logo({ variant = 'wordmark', tone = 'marine', size = 32, title = 'greenhueblues', style }) {
  const [fg, dot] = TONES[tone] || TONES.marine;
  const base = {
    fontFamily: 'var(--font-sans)',
    fontWeight: 700,
    letterSpacing: '-0.035em',
    fontSize: size,
    lineHeight: variant === 'stacked' ? 0.86 : 1,
    color: fg,
    display: 'inline-block',
    whiteSpace: 'nowrap',
    fontStyle: 'normal',
    ...style,
  };
  const Dot = <span style={{ color: dot }}>.</span>;
  if (variant === 'stacked') {
    return (
      <span role="img" aria-label={title} style={{ ...base, display: 'inline-flex', flexDirection: 'column' }}>
        <span>green</span><span>hue</span><span>blues{Dot}</span>
      </span>
    );
  }
  return (
    <span role="img" aria-label={title} style={base}>
      {variant === 'monogram' ? 'ghb' : 'greenhueblues'}{Dot}
    </span>
  );
}
