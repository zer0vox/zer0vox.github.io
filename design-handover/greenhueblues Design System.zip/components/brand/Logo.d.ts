/** greenhueblues wordmark, set live in Neue Haas Unica Pro Bold with the signature red full stop. */
export interface LogoProps {
  /** wordmark: one line · stacked: green / hue / blues. · monogram: ghb. */
  variant?: 'wordmark' | 'stacked' | 'monogram';
  /** marine (default, on paper) · ink · inverse (on marine/ink) · mono (currentColor, dot included) */
  tone?: 'marine' | 'ink' | 'inverse' | 'mono';
  /** Font size in px; cap height ≈ 0.71 × size. Default 32. */
  size?: number;
  /** Accessible name. Default "greenhueblues". */
  title?: string;
  style?: React.CSSProperties;
}
export declare function Logo(props: LogoProps): JSX.Element;
