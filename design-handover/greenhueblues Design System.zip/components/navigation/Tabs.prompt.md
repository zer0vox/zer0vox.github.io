Use Tabs to switch views within a page (work filters, project sections, settings).

```jsx
<Tabs items={[{ id: 'all', label: 'All', count: 24 }, { id: 'identity', label: 'Identity' }]} onChange={setFilter} />
<Tabs variant="segment" items={['Grid', 'List']} />
```

- `line`: 2px ink underline on active. `segment`: pill on sunken track.
