import React from 'react';

export function Tabs({ items = [], value, defaultValue, onChange, variant = 'line', tone = 'default', style }) {
  const list = items.map((i) => (typeof i === 'string' ? { id: i, label: i } : i));
  const [inner, setInner] = React.useState(defaultValue ?? (list[0] && list[0].id));
  const current = value ?? inner;
  const [hoverId, setHoverId] = React.useState(null);
  const pick = (id) => { if (value === undefined) setInner(id); onChange && onChange(id); };
  const inverse = tone === 'inverse';

  if (variant === 'segment') {
    return (
      <div role="tablist" style={{ display: 'inline-flex', gap: 2, padding: 3, borderRadius: 'var(--radius-pill)', background: inverse ? 'rgba(244,242,237,0.1)' : 'var(--surface-sunken)', ...style }}>
        {list.map((t) => {
          const on = t.id === current;
          return (
            <button key={t.id} role="tab" type="button" aria-selected={on} onClick={() => pick(t.id)}
              style={{
                height: 30, padding: '0 14px', border: 0, borderRadius: 'var(--radius-pill)', cursor: 'pointer',
                fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)', fontWeight: on ? 'var(--weight-medium)' : 400,
                background: on ? (inverse ? 'var(--paper-100)' : 'var(--surface-raised)') : 'transparent',
                color: on ? (inverse ? 'var(--marine-800)' : 'var(--text-primary)') : (inverse ? 'var(--text-on-inverse-muted)' : 'var(--text-secondary)'),
                boxShadow: on && !inverse ? 'var(--shadow-pop)' : 'none',
                transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
              }}>
              {t.label}
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div role="tablist" style={{ display: 'flex', gap: 28, borderBottom: `1px solid ${inverse ? 'var(--border-inverse)' : 'var(--border-subtle)'}`, overflowX: 'auto', overflowY: 'hidden', ...style }}>
      {list.map((t) => {
        const on = t.id === current;
        const hov = hoverId === t.id;
        return (
          <button key={t.id} role="tab" type="button" aria-selected={on} onClick={() => pick(t.id)}
            onMouseEnter={() => setHoverId(t.id)} onMouseLeave={() => setHoverId(null)}
            style={{
              position: 'relative', display: 'inline-flex', alignItems: 'baseline', gap: 6, padding: '12px 0', marginBottom: -1, border: 0, background: 'transparent', cursor: 'pointer',
              fontFamily: 'var(--font-sans)', fontSize: 'var(--text-base)', fontWeight: on ? 'var(--weight-medium)' : 400, whiteSpace: 'nowrap',
              color: on || hov ? (inverse ? 'var(--paper-100)' : 'var(--text-primary)') : (inverse ? 'var(--text-on-inverse-muted)' : 'var(--text-tertiary)'),
              boxShadow: on ? `inset 0 -2px 0 ${inverse ? 'var(--paper-100)' : 'var(--ink-900)'}` : 'none',
              transition: 'color var(--dur-fast) var(--ease-out)',
            }}>
            {t.label}
            {t.count != null && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-2xs)', fontWeight: 400, opacity: 0.8 }}>{t.count}</span>}
          </button>
        );
      })}
    </div>
  );
}
