/** Tab bar — underline (default) or segmented pill. Controlled or uncontrolled. */
export interface TabItem { id: string; label: React.ReactNode; count?: number | string; }
export interface TabsProps {
  items: Array<string | TabItem>;
  value?: string;
  defaultValue?: string;
  onChange?: (id: string) => void;
  variant?: 'line' | 'segment';
  tone?: 'default' | 'inverse';
  style?: React.CSSProperties;
}
export declare function Tabs(props: TabsProps): JSX.Element;
