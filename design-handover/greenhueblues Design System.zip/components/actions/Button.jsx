import React from 'react';
import { Icon } from '../brand/Icon.jsx';

const SIZES = {
  sm: { height: 'var(--control-height-sm)', padding: '0 14px', fontSize: 'var(--text-sm)', gap: 6, icon: 16 },
  md: { height: 'var(--control-height-md)', padding: '0 18px', fontSize: 'var(--text-sm)', gap: 8, icon: 18 },
  lg: { height: 'var(--control-height-lg)', padding: '0 26px', fontSize: 'var(--text-base)', gap: 10, icon: 20 },
};

const VARIANTS = {
  primary: {
    base: { background: 'var(--color-primary)', color: 'var(--text-on-primary)', borderColor: 'var(--color-primary)' },
    hover: { background: 'var(--color-primary-hover)', borderColor: 'var(--color-primary-hover)' },
  },
  secondary: {
    base: { background: 'transparent', color: 'var(--text-primary)', borderColor: 'var(--border-strong)' },
    hover: { background: 'var(--ink-900)', color: 'var(--paper-100)', borderColor: 'var(--ink-900)' },
  },
  ghost: {
    base: { background: 'transparent', color: 'var(--text-primary)', borderColor: 'transparent' },
    hover: { background: 'var(--surface-press)' },
  },
  accent: {
    base: { background: 'var(--color-accent)', color: 'var(--text-on-accent)', borderColor: 'var(--color-accent)' },
    hover: { background: 'var(--red-400)', borderColor: 'var(--red-400)' },
  },
  highlight: {
    base: { background: 'var(--color-highlight)', color: 'var(--text-on-highlight)', borderColor: 'var(--color-highlight)' },
    hover: { background: 'var(--butter-500)', borderColor: 'var(--butter-500)' },
  },
  inverse: {
    base: { background: 'var(--paper-100)', color: 'var(--marine-800)', borderColor: 'var(--paper-100)' },
    hover: { background: 'var(--butter-400)', borderColor: 'var(--butter-400)' },
  },
};

export function Button({
  variant = 'primary', size = 'md', iconLeft, iconRight, href, disabled = false, fullWidth = false,
  type = 'button', children, style, onClick, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [press, setPress] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  const Tag = href ? 'a' : 'button';
  const live = hover && !disabled;
  const css = {
    display: fullWidth ? 'flex' : 'inline-flex', width: fullWidth ? '100%' : undefined,
    alignItems: 'center', justifyContent: 'center', gap: s.gap,
    height: s.height, padding: s.padding, borderRadius: 'var(--radius-pill)', borderWidth: 1, borderStyle: 'solid',
    fontFamily: 'var(--font-sans)', fontSize: s.fontSize, fontWeight: 'var(--weight-medium)', letterSpacing: '-0.005em',
    lineHeight: 1, whiteSpace: 'nowrap', textDecoration: 'none', cursor: disabled ? 'not-allowed' : 'pointer', userSelect: 'none',
    transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out), transform var(--dur-instant) var(--ease-out)',
    ...v.base, ...(live ? v.hover : null),
    transform: press && !disabled ? 'translateY(1px)' : 'none',
    opacity: disabled ? 0.4 : 1,
    ...style,
  };
  return (
    <Tag
      href={disabled ? undefined : href}
      type={href ? undefined : type}
      disabled={href ? undefined : disabled}
      aria-disabled={disabled || undefined}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setPress(false); }}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      style={css}
      {...rest}
    >
      {iconLeft && <Icon name={iconLeft} size={s.icon} />}
      {children}
      {iconRight && (
        <Icon name={iconRight} size={s.icon} style={{ transition: 'transform var(--dur-base) var(--ease-out)', transform: live ? 'translateX(3px)' : 'none' }} />
      )}
    </Tag>
  );
}
