Use Button for actions; one `primary` per view, `secondary` for the alternative, `ghost` for tertiary.

```jsx
<Button iconRight="arrow-right">Start a project</Button>
<Button variant="secondary">View work</Button>
<Button variant="inverse" size="lg">Say hello</Button>   // on marine
```

- Variants: primary (marine), secondary (ink outline → inverts on hover), ghost, accent (red, ink text — sparingly), highlight (butter), inverse.
- Sizes sm 32 / md 40 / lg 52. Always pill. `href` renders a link.
- `iconRight="arrow-right"` nudges 3px on hover — the standard CTA pattern.
