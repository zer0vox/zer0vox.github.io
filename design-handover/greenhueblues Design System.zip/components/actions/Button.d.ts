/**
 * Pill-shaped action button.
 */
export interface ButtonProps {
  /** primary = marine fill (one per view) · secondary = ink outline · ghost · accent = red (rare, high-energy) · highlight = butter · inverse = on marine/ink surfaces */
  variant?: 'primary' | 'secondary' | 'ghost' | 'accent' | 'highlight' | 'inverse';
  /** sm 32px · md 40px · lg 52px */
  size?: 'sm' | 'md' | 'lg';
  /** Lucide icon name before the label */
  iconLeft?: string;
  /** Lucide icon name after the label — nudges right on hover (use "arrow-right") */
  iconRight?: string;
  /** Renders an <a> when set */
  href?: string;
  disabled?: boolean;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
