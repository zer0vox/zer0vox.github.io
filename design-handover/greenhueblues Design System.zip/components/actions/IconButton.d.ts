/** Circular icon-only button. Always pass a label. */
export interface IconButtonProps {
  /** Lucide icon name */
  icon: string;
  /** Accessible label (also used as title) */
  label: string;
  variant?: 'primary' | 'secondary' | 'ghost' | 'accent' | 'inverse';
  /** sm 32 · md 40 · lg 52 */
  size?: 'sm' | 'md' | 'lg';
  href?: string;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
