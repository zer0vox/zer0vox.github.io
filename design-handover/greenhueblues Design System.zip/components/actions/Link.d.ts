/** Text link with hairline underline; optional trailing arrow. Hover turns red (or butter on inverse). */
export interface LinkProps {
  href?: string;
  children?: React.ReactNode;
  /** right = internal CTA · up-right = external */
  arrow?: 'right' | 'up-right';
  tone?: 'default' | 'brand' | 'muted' | 'inverse';
  underline?: 'always' | 'hover' | 'none';
  /** font-size override */
  size?: number | string;
  /** Opens in a new tab */
  external?: boolean;
  style?: React.CSSProperties;
}
export declare function Link(props: LinkProps): JSX.Element;
