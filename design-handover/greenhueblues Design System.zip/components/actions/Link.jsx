import React from 'react';
import { Icon } from '../brand/Icon.jsx';

const TONES = {
  default: { color: 'var(--text-primary)', hover: 'var(--text-accent)' },
  brand: { color: 'var(--text-brand)', hover: 'var(--text-accent)' },
  muted: { color: 'var(--text-secondary)', hover: 'var(--text-primary)' },
  inverse: { color: 'var(--text-on-inverse)', hover: 'var(--butter-400)' },
};

export function Link({ href = '#', children, arrow, tone = 'default', underline = 'always', size, external, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const t = TONES[tone] || TONES.default;
  const arrowName = arrow === 'right' ? 'arrow-right' : arrow === 'up-right' ? 'arrow-up-right' : null;
  const showLine = underline === 'always' || (underline === 'hover' && hover);
  return (
    <a
      href={href}
      target={external ? '_blank' : undefined}
      rel={external ? 'noreferrer' : undefined}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: '0.3em',
        color: hover ? t.hover : t.color, fontSize: size, fontFamily: 'inherit',
        textDecorationLine: showLine ? 'underline' : 'none', textDecorationThickness: '1px', textUnderlineOffset: '0.2em',
        transition: 'color var(--dur-fast) var(--ease-out)', cursor: 'pointer', ...style,
      }}
      {...rest}
    >
      <span>{children}</span>
      {arrowName && (
        <Icon name={arrowName} size="0.95em" strokeWidth={1.75}
          style={{ transition: 'transform var(--dur-base) var(--ease-out)', transform: hover ? (arrow === 'right' ? 'translateX(3px)' : 'translate(2px,-2px)') : 'none' }} />
      )}
    </a>
  );
}
