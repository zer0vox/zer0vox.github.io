Use Link for inline and standalone text links; hairline underline, red on hover.

```jsx
<Link href="/work" arrow="right">All work</Link>
<Link href="https://instagram.com" arrow="up-right" external underline="hover">Instagram</Link>
```

- `arrow="right"` for internal CTAs, `"up-right"` for external. Tones: default, brand, muted, inverse (hover butter).
