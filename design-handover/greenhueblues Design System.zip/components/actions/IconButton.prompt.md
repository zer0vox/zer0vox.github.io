Use IconButton for icon-only actions (close, menu, carousel arrows, social).

```jsx
<IconButton icon="arrow-left" label="Previous" />
<IconButton icon="x" label="Close" variant="ghost" size="sm" />
```

- Circular. Variants: secondary (default, ink outline), primary, ghost, accent, inverse. `label` is required.
