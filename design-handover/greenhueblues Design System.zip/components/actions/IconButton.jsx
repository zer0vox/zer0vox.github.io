import React from 'react';
import { Icon } from '../brand/Icon.jsx';

const SIZES = { sm: { box: 32, icon: 16 }, md: { box: 40, icon: 18 }, lg: { box: 52, icon: 22 } };
const VARIANTS = {
  primary: { base: { background: 'var(--color-primary)', color: 'var(--text-on-primary)', borderColor: 'var(--color-primary)' }, hover: { background: 'var(--color-primary-hover)' } },
  secondary: { base: { background: 'transparent', color: 'var(--text-primary)', borderColor: 'var(--border-strong)' }, hover: { background: 'var(--ink-900)', color: 'var(--paper-100)' } },
  ghost: { base: { background: 'transparent', color: 'var(--text-primary)', borderColor: 'transparent' }, hover: { background: 'var(--surface-press)' } },
  accent: { base: { background: 'var(--color-accent)', color: 'var(--text-on-accent)', borderColor: 'var(--color-accent)' }, hover: { background: 'var(--red-400)' } },
  inverse: { base: { background: 'transparent', color: 'var(--paper-100)', borderColor: 'var(--border-inverse)' }, hover: { background: 'var(--paper-100)', color: 'var(--marine-800)' } },
};

export function IconButton({ icon, label, variant = 'secondary', size = 'md', href, disabled = false, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const Tag = href ? 'a' : 'button';
  return (
    <Tag
      href={href}
      type={href ? undefined : 'button'}
      aria-label={label}
      title={label}
      disabled={href ? undefined : disabled}
      onClick={disabled ? undefined : onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
        width: s.box, height: s.box, padding: 0, borderRadius: 'var(--radius-pill)', borderWidth: 1, borderStyle: 'solid',
        cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.4 : 1, textDecoration: 'none',
        transition: 'background-color var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
        ...v.base, ...(hover && !disabled ? v.hover : null), ...style,
      }}
      {...rest}
    >
      <Icon name={icon} size={s.icon} />
    </Tag>
  );
}
