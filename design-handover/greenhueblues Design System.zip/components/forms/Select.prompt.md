Use Select for picking one option from a short list; matches Input visually.

```jsx
<Select label="Budget" placeholder="Choose a range" options={['< 25k', '25–75k', '75k +']} />
```
