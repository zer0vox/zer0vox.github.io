import React from 'react';

export function Radio({ checked = false, onChange, label, description, disabled = false, value, name, style }) {
  return (
    <label style={{ display: 'inline-flex', alignItems: 'flex-start', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1, ...style }}>
      <button
        type="button"
        role="radio"
        aria-checked={checked}
        name={name}
        value={value}
        disabled={disabled}
        onClick={() => !disabled && onChange && onChange(value)}
        style={{
          width: 18, height: 18, marginTop: 2, flexShrink: 0, padding: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: '50%', border: `1.5px solid ${checked ? 'var(--marine-700)' : 'var(--ink-500)'}`, background: 'var(--surface-raised)', cursor: 'inherit',
          transition: 'border-color var(--dur-fast) var(--ease-out)',
        }}
      >
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--marine-700)', transform: checked ? 'scale(1)' : 'scale(0)', transition: 'transform var(--dur-fast) var(--ease-out)' }} />
      </button>
      {(label || description) && (
        <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }} onClick={(e) => { e.preventDefault(); !disabled && onChange && onChange(value); }}>
          {label && <span style={{ fontSize: 'var(--text-sm)', lineHeight: 1.5, color: 'var(--text-primary)' }}>{label}</span>}
          {description && <span style={{ fontSize: 'var(--text-xs)', lineHeight: 1.45, color: 'var(--text-tertiary)' }}>{description}</span>}
        </span>
      )}
    </label>
  );
}

export function RadioGroup({ name, options = [], value, defaultValue, onChange, direction = 'column', label, disabled }) {
  const [inner, setInner] = React.useState(defaultValue);
  const current = value ?? inner;
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  const pick = (v) => { if (value === undefined) setInner(v); onChange && onChange(v); };
  return (
    <div role="radiogroup" aria-label={label} style={{ display: 'flex', flexDirection: direction, gap: direction === 'row' ? 20 : 10, flexWrap: 'wrap' }}>
      {opts.map((o) => (
        <Radio key={o.value} name={name} value={o.value} label={o.label} description={o.description} checked={current === o.value} disabled={disabled || o.disabled} onChange={pick} />
      ))}
    </div>
  );
}
