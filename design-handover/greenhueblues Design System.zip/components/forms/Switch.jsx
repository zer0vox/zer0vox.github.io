import React from 'react';

export function Switch({ checked, defaultChecked = false, onChange, label, disabled = false, size = 'md', style }) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked ?? inner;
  const dims = size === 'sm' ? { w: 28, h: 16, k: 12 } : { w: 36, h: 20, k: 16 };
  const toggle = () => {
    if (disabled) return;
    if (checked === undefined) setInner(!isOn);
    onChange && onChange(!isOn);
  };
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1, ...style }}>
      <button
        type="button"
        role="switch"
        aria-checked={isOn}
        disabled={disabled}
        onClick={toggle}
        style={{
          position: 'relative', width: dims.w, height: dims.h, padding: 0, border: 0, flexShrink: 0, cursor: 'inherit',
          borderRadius: 'var(--radius-pill)', background: isOn ? 'var(--marine-700)' : 'var(--paper-400)',
          transition: 'background-color var(--dur-base) var(--ease-out)',
        }}
      >
        <span style={{
          position: 'absolute', top: (dims.h - dims.k) / 2, left: (dims.h - dims.k) / 2, width: dims.k, height: dims.k, borderRadius: '50%',
          background: 'var(--paper-0)', boxShadow: '0 1px 2px rgba(0,31,49,0.2)',
          transform: isOn ? `translateX(${dims.w - dims.h}px)` : 'none', transition: 'transform var(--dur-base) var(--ease-out)',
        }} />
      </button>
      {label && <span onClick={(e) => { e.preventDefault(); toggle(); }} style={{ fontSize: 'var(--text-sm)', color: 'var(--text-primary)' }}>{label}</span>}
    </label>
  );
}
