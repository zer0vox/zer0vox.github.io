import React from 'react';
import { Icon } from '../brand/Icon.jsx';

export function Checkbox({ checked, defaultChecked = false, onChange, label, description, disabled = false, indeterminate = false, style }) {
  const [inner, setInner] = React.useState(defaultChecked);
  const isOn = checked ?? inner;
  const toggle = () => {
    if (disabled) return;
    const next = !isOn;
    if (checked === undefined) setInner(next);
    onChange && onChange(next);
  };
  const filled = isOn || indeterminate;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'flex-start', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer', opacity: disabled ? 0.45 : 1, ...style }}>
      <button
        type="button"
        role="checkbox"
        aria-checked={indeterminate ? 'mixed' : isOn}
        disabled={disabled}
        onClick={toggle}
        style={{
          width: 18, height: 18, marginTop: 2, flexShrink: 0, padding: 0, display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: 'var(--radius-xs)', border: `1.5px solid ${filled ? 'var(--marine-700)' : 'var(--ink-500)'}`,
          background: filled ? 'var(--marine-700)' : 'var(--surface-raised)', color: 'var(--paper-100)', cursor: 'inherit',
          transition: 'background-color var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)',
        }}
      >
        {indeterminate ? <Icon name="minus" size={14} strokeWidth={2.5} /> : isOn ? <Icon name="check" size={14} strokeWidth={2.5} /> : null}
      </button>
      {(label || description) && (
        <span style={{ display: 'flex', flexDirection: 'column', gap: 2 }} onClick={(e) => { e.preventDefault(); toggle(); }}>
          {label && <span style={{ fontSize: 'var(--text-sm)', lineHeight: 1.5, color: 'var(--text-primary)' }}>{label}</span>}
          {description && <span style={{ fontSize: 'var(--text-xs)', lineHeight: 1.45, color: 'var(--text-tertiary)' }}>{description}</span>}
        </span>
      )}
    </label>
  );
}
