import React from 'react';
import { Icon } from '../brand/Icon.jsx';
import { Field, fieldShell } from './Input.jsx';

let uid = 0;

export function Select({ id, label, hint, error, options = [], placeholder, variant = 'box', disabled, value, defaultValue, onChange, style, ...rest }) {
  const fid = React.useMemo(() => id || 'ghb-sel-' + (++uid), [id]);
  const [focused, setFocused] = React.useState(false);
  const shell = fieldShell({ variant, focused, error, disabled });
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  return (
    <Field id={fid} label={label} hint={hint} error={error} variant={variant}>
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', transition: 'box-shadow var(--dur-fast) var(--ease-out)', ...shell, paddingRight: 0, ...style }}>
        <select
          id={fid}
          disabled={disabled}
          value={value}
          defaultValue={value === undefined ? (defaultValue ?? (placeholder ? '' : undefined)) : undefined}
          onChange={onChange}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          style={{
            appearance: 'none', WebkitAppearance: 'none', flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent',
            font: 'inherit', fontFamily: 'var(--font-sans)', fontSize: 'inherit', color: 'var(--text-primary)',
            height: variant === 'line' ? 46 : 38, padding: '0 36px 0 0', margin: 0, cursor: disabled ? 'not-allowed' : 'pointer',
          }}
          {...rest}
        >
          {placeholder && <option value="" disabled>{placeholder}</option>}
          {opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <Icon name="chevron-down" size={16} color="var(--text-secondary)" style={{ position: 'absolute', right: variant === 'line' ? 0 : 12, pointerEvents: 'none' }} />
      </div>
    </Field>
  );
}
