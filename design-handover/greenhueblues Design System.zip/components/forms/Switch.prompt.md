Use Switch for settings that apply immediately (motion, theme, notifications).

```jsx
<Switch label="Reduce motion" defaultChecked />
```
