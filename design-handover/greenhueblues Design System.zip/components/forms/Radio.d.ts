/** Single radio (controlled). Use RadioGroup for a managed set. */
export interface RadioProps {
  checked?: boolean;
  onChange?: (value: string) => void;
  value?: string;
  name?: string;
  label?: React.ReactNode;
  description?: React.ReactNode;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Radio(props: RadioProps): JSX.Element;
export interface RadioGroupProps {
  name?: string;
  label?: string;
  options: Array<string | { value: string; label: React.ReactNode; description?: React.ReactNode; disabled?: boolean }>;
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  direction?: 'row' | 'column';
  disabled?: boolean;
}
export declare function RadioGroup(props: RadioGroupProps): JSX.Element;
