Use Checkbox for independent multi-select options and consent.

```jsx
<Checkbox label="Identity" defaultChecked />
<Checkbox label="Send me the studio letter" description="Four times a year." />
```
