import React from 'react';
import { Icon } from '../brand/Icon.jsx';

let uid = 0;
const useId = (id) => React.useMemo(() => id || 'ghb-in-' + (++uid), [id]);

export function Field({ id, label, hint, error, variant = 'box', children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: variant === 'line' ? 4 : 6, minWidth: 0 }}>
      {label && (
        <label htmlFor={id} style={variant === 'line'
          ? { fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase', color: 'var(--text-tertiary)' }
          : { fontFamily: 'var(--font-sans)', fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-medium)', color: 'var(--text-primary)' }}>
          {label}
        </label>
      )}
      {children}
      {(error || hint) && (
        <span style={{ fontSize: 'var(--text-xs)', lineHeight: 1.4, color: error ? 'var(--status-danger)' : 'var(--text-tertiary)' }}>{error || hint}</span>
      )}
    </div>
  );
}

export function fieldShell({ variant, focused, error, disabled, multiline }) {
  if (variant === 'line') {
    return {
      background: 'transparent', border: 0, borderRadius: 0,
      boxShadow: `inset 0 -${focused ? 2 : 1}px 0 ${error ? 'var(--red-600)' : focused ? 'var(--marine-700)' : 'var(--border-strong)'}`,
      minHeight: multiline ? undefined : 48, padding: multiline ? '8px 0' : '0',
      fontSize: 'var(--text-md)', opacity: disabled ? 0.45 : 1,
    };
  }
  return {
    background: disabled ? 'var(--surface-sunken)' : 'var(--surface-raised)',
    border: `1px solid ${error ? 'var(--red-600)' : focused ? 'var(--marine-700)' : 'var(--border-default)'}`,
    borderRadius: 'var(--radius-xs)',
    boxShadow: focused ? `0 0 0 3px ${error ? 'var(--red-100)' : 'var(--marine-100)'}` : 'none',
    minHeight: multiline ? undefined : 'var(--control-height-md)', padding: multiline ? '10px 12px' : '0 12px',
    fontSize: 'var(--text-sm)', opacity: disabled ? 0.6 : 1,
  };
}

export function Input({ id, label, hint, error, iconLeft, variant = 'box', multiline = false, rows = 4, disabled, style, onFocus, onBlur, ...rest }) {
  const fid = useId(id);
  const [focused, setFocused] = React.useState(false);
  const shell = fieldShell({ variant, focused, error, disabled, multiline });
  const Tag = multiline ? 'textarea' : 'input';
  return (
    <Field id={fid} label={label} hint={hint} error={error} variant={variant}>
      <div style={{ display: 'flex', alignItems: multiline ? 'flex-start' : 'center', gap: 8, transition: 'box-shadow var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)', ...shell, ...style }}>
        {iconLeft && <Icon name={iconLeft} size={16} color="var(--text-tertiary)" />}
        <Tag
          id={fid}
          rows={multiline ? rows : undefined}
          disabled={disabled}
          aria-invalid={error ? true : undefined}
          onFocus={(e) => { setFocused(true); onFocus && onFocus(e); }}
          onBlur={(e) => { setFocused(false); onBlur && onBlur(e); }}
          style={{
            flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent', padding: 0, margin: 0,
            font: 'inherit', fontFamily: 'var(--font-sans)', fontSize: 'inherit', color: 'var(--text-primary)',
            lineHeight: multiline ? 1.5 : undefined, height: multiline ? undefined : variant === 'line' ? 46 : 38, resize: multiline ? 'vertical' : undefined,
          }}
          {...rest}
        />
      </div>
    </Field>
  );
}
