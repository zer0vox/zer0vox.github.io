Use RadioGroup for one-of-many choices with all options visible (≤ 5).

```jsx
<RadioGroup name="timeline" defaultValue="q1" options={[{ value: 'asap', label: 'As soon as possible' }, { value: 'q1', label: 'Next quarter' }]} />
```

- `Radio` alone is controlled-only; `direction="row"` for short labels.
