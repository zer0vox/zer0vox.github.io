Use Input for text entry; `box` in product UI, `line` for editorial forms like the contact page.

```jsx
<Input label="Email" placeholder="you@studio.com" hint="We reply within two days." />
<Input variant="line" label="Your name" />
<Input label="Brief" multiline rows={5} />
```

- `error` turns the border red and replaces the hint. `iconLeft` for search fields.
- Focus: marine border + 3px marine-100 halo (box) or 2px marine underline (line).
