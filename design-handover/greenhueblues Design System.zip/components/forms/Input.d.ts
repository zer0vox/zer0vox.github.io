/**
 * Text field (single or multi-line) with label, hint and error.
 */
export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'style'> {
  id?: string;
  label?: React.ReactNode;
  hint?: React.ReactNode;
  /** Error message — also turns the border red */
  error?: React.ReactNode;
  /** Lucide icon name shown inside the field */
  iconLeft?: string;
  /** box = bordered white field (apps, filters) · line = underline only, larger type (editorial forms, contact) */
  variant?: 'box' | 'line';
  /** Renders a <textarea> */
  multiline?: boolean;
  rows?: number;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
export interface FieldProps { id?: string; label?: React.ReactNode; hint?: React.ReactNode; error?: React.ReactNode; variant?: 'box' | 'line'; children?: React.ReactNode; }
/** Label + hint/error wrapper used by Input and Select. */
export declare function Field(props: FieldProps): JSX.Element;
